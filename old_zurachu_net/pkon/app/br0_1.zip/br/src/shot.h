/*
 * $Id: shot.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * Shot data.
 */
#include "vector.h"

typedef struct {
  Vector pos;
  int d;
  int cnt;
} Shot;

#define SHOT_MAX 8

extern Shot shot[];

void initShots();
void moveShots();
void drawShots();
void addShot(Vector *pos, int d);
