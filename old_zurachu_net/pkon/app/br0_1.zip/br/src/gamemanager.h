/*
 * $Id: gamemanager.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Game manager.
 */
#include "seed.h"

#define TITLE 0
#define IN_GAME 1
#define GAMEOVER 2

typedef struct {
  int cnt, type;
  float rank;
  int limiterBulletsNum;
  int seedMax, seedAppItv;
  int score, hiScore;
  int left;
} GameStatus;

extern GameStatus gameStatus;

void initGamemanager();
void startGame();
void startGameover();
void addScore();
void downRank();
int decrementShip();
void moveGamemanager();
void drawGamemanager();
void loadHiScore();
void saveHiScore();
