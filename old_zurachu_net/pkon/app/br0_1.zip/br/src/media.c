/*
 * $Id: media.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * Screen/Sound for P/ECE.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "media.h"
#include "genmcr.h"
#include "reactor.h"

unsigned char vbuf[SCREEN_WIDTH*SCREEN_HEIGHT];

void clearScreen() {
  memset(vbuf, 0, SCREEN_WIDTH*SCREEN_HEIGHT);
}

void drawLine(int c, int x1, int y1, int x2, int y2) {
  if ( x1 < x2 ) {
    if ( x1 < 0 ) {
      if ( x2 < 0 ) return;
      y1 = (y2-y1)*-x1/(x2-x1) + y1;
      x1 = 0;
    }
    if ( x2 >= SCREEN_WIDTH ) {
      if ( x1 >= SCREEN_WIDTH ) return;
      y2 = (y1-y2)*(SCREEN_WIDTH-x2)/(x1-x2) + y2;
      x2 = SCREEN_WIDTH-1;
    }
  } else {
    if ( x2 < 0 ) {
      if ( x1 < 0 ) return;
      y2 = (y1-y2)*-x2/(x1-x2) + y2;
      x2 = 0;
    }
    if ( x1 >= SCREEN_WIDTH ) {
      if ( x2 >= SCREEN_WIDTH ) return;
      y1 = (y2-y1)*(SCREEN_WIDTH-x1)/(x2-x1) + y1;
      x1 = SCREEN_WIDTH-1;
    }
  }
  if ( y1 < y2 ) {
    if ( y1 < 0 ) {
      if ( y2 < 0 ) return;
      x1 = (x2-x1)*-y1/(y2-y1) + x1;
      y1 = 0;
    }
    if ( y2 >= SCREEN_HEIGHT ) {
      if ( y1 >= SCREEN_HEIGHT ) return;
      x2 = (x1-x2)*(SCREEN_HEIGHT-y2)/(y1-y2) + x2;
      y2 = SCREEN_HEIGHT-1;
    }
  } else {
    if ( y2 < 0 ) {
      if ( y1 < 0 ) return;
      x2 = (x1-x2)*-y2/(y1-y2) + x2;
      y2 = 0;
    }
    if ( y1 >= SCREEN_HEIGHT ) {
      if ( y2 >= SCREEN_HEIGHT ) return;
      x1 = (x2-x1)*(SCREEN_HEIGHT-y1)/(y2-y1) + x1;
      y1 = SCREEN_HEIGHT-1;
    }
  }
  pceLCDLine(c, x1, y1, x2, y2);
}

static int min[SCREEN_HEIGHT], max[SCREEN_HEIGHT];
static int top, btm;

void startDrawPolygon() {
  int y;
  top = +2147483647;
  btm = -2147483647;
  for ( y=0 ; y<SCREEN_HEIGHT ; y++ ) {
    min[y] = +2147483647;
    max[y] = -2147483647;
  }
}

void scanEdge(int x1, int y1, int x2, int y2) {
  int l, addx, addy, x, y, i;
  int px, py;

  if ( y1 < top ) top = y1;
  if ( y2 < top ) top = y2;
  if ( y1 > btm ) btm = y1;
  if ( y2 > btm ) btm = y2;
  if ( top < 0 ) top = 0;
  if ( btm >= SCREEN_HEIGHT ) btm = SCREEN_HEIGHT;

  l = absN(y2-y1) + 1;
	
  addx = ((x2 - x1)<<8) / l;
  addy = ((y2 - y1)<<8) / l;

  x = x1<<8;
  y = y1<<8;

  for ( i=0 ; i<l ; i++, x+=addx, y+=addy ) {
    py = y>>8; px = x>>8;
    if ( py < 0 || py >= SCREEN_HEIGHT ) continue;
    if ( min[py] > px ){
      min [py] = px;
    }
    if ( max[py] < px ){
      max [py] = px;
    }
  }
}

void drawPolygon(int ec, int pc) {
  int y, sx, lgt;
  unsigned char *vbOfs;
  for ( y=top ; y<btm ; y++ ) {
    if ( min[y] == +2147483647 ) continue;
    sx = min[y];
    if ( sx < 0 ) sx = 0;
    lgt = max[y];
    if ( lgt >= SCREEN_WIDTH ) lgt = SCREEN_WIDTH-1;
    lgt -= sx;
    if ( lgt <= 0 ) continue;
    //vbOfs = &(vbuf[y*SCREEN_WIDTH+sx]);
    vbOfs = &(vbuf[(y<<7)+sx]);
    if ( y==top || y==btm-1 ) {
      memset(vbOfs, ec, lgt);
    } else {
      *vbOfs = ec;
      if ( lgt > 2 ) {
	memset(vbOfs+1, pc, lgt-2);
      }
      *(vbOfs+lgt) = ec;
    }
  }
}

// Handle sounds.

#ifndef _PIECE2SDL
static PCEWAVEINFO wtemp;
static int prvAtt[4];
#else
unsigned char PCM_R1[] = {1};
unsigned char PCM_R2[] = {1};
unsigned char PCM_R3[] = {1};
unsigned char PCM_BONUS[] = {1};
unsigned char PCM_BLBRK[] = {1};
unsigned char PCM_HIT[] = {1};
unsigned char PCM_SDBRK[] = {1};
unsigned char PCM_MISS[] = {1};
unsigned char PCM_EXTEND[] = {1};
#endif

#define DEFAULT_VOLUME 6

static char *bgm;
static int bgmVolume;
static char *bgmChange;
static unsigned long bgmCount, beatCount;

void changeVolume(int ch, int v) {
#ifndef _PIECE2SDL
  pceWaveSetChAtt(ch, v);
#endif
}

void initSound() {
#ifndef _PIECE2SDL
  int i;
  for ( i=0 ; i<4 ; i++ ) {
    changeVolume(i, DEFAULT_VOLUME);
  }
#endif
  bgm = NULL;
  bgmCount = beatCount = 0;
}

void playSeNow(char *snd, int ch) {
#ifndef _PIECE2SDL
  wtemp = *((PCEWAVEINFO*)(snd + 8));
  wtemp.pData = snd + 8 + sizeof(PCEWAVEINFO);
  pceWaveDataOut(ch, &wtemp);
#endif
}

void stopSeNow(int ch) {
#ifndef _PIECE2SDL
  pceWaveAbort(ch);
#endif
}

void stopSe() {
#ifndef _PIECE2SDL
  int i;
  for ( i=0 ; i<4 ; i++ ) {
    pceWaveAbort(i);
  }
#endif
}

void saveWaveAtt() {
#ifndef _PIECE2SDL
  int i;
  for ( i=0 ; i<4 ; i++ ) {
    prvAtt[i] = pceWaveSetChAtt(i, INVALIDVAL);
  }
#endif
}

void loadWaveAtt() {
#ifndef _PIECE2SDL
  int i;
  for ( i=0 ; i<4 ; i++ ) {
    pceWaveSetChAtt(i, prvAtt[i]);
  }
#endif
}

void startBGM(char *snd) {
  bgm = snd;
  bgmVolume = DEFAULT_VOLUME<<2;
  changeVolume(0, bgmVolume>>2);
  bgmChange = NULL;
}

void stopBGM() {
  bgm = NULL;
  stopSeNow(0);
}

void changeBGM(char *cg) {
  bgmChange = cg;
}

void playBGM() {
  unsigned long tc;
  if ( bgm == NULL ) return;
  tc = pceTimerGetCount();
  if ( tc - bgmCount > INTERVAL*120+INTERVAL/2 ) {
    if ( bgmChange ) bgm = bgmChange;
#ifndef _PIECE2SDL
    playSeNow(bgm, 0);
#endif
    bgmCount = tc; 
    beatCount = tc - (INTERVAL*14+INTERVAL/2)/2;
  } 
  if ( tc - beatCount >= INTERVAL*14+INTERVAL/2 ) {
    beatReactor();
    beatCount = tc;
  }
}
