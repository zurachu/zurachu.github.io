/*
 * $Id: bmlprs.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * BulletML parser.
 */
#ifndef BMLPRS_H_
#define BMLPRS_H_
#include "expression.h"

#define ACTION 0
#define ACTION_REF 1
#define BULLET 2
#define BULLET_REF 3
#define FIRE 3
#define FIRE_REF 4
#define REPEAT 5
#define WAIT 6
#define CHANGE_DIRECTION 7
#define CHANGE_SPEED 8
#define VANISH 9
#define ACCEL 10

#define AIM 0
#define ABSOLUTE 1
#define RELATIVE 2
#define SEQUENCE 3

#define IACTIONCHOICE 0
#define IACTIONELMCHOICE 1

#define CHOICE_MAX 8
#define LABEL_MAX 8
#define PARAM_MAX 2

typedef struct {
  Expression prm[PARAM_MAX];
  int idx;
} Params;

struct direction {
  int type;
  Expression num;
};
typedef struct direction Direction;

struct speed {
  int type;
  Expression num;
};
typedef struct speed Speed;

typedef union {
  struct action *a;
  struct actionref *ar;
} IActionElmChoiceUnion;

struct iactionelmchoice {
  int n;
  IActionElmChoiceUnion u;
};
typedef struct iactionelmchoice IActionElmChoice;

struct repeat {
  Expression times;
  struct iactionelmchoice a[1];
};
typedef struct repeat Repeat;

struct bullet {
  char label[LABEL_MAX];
  struct direction d;
  struct speed s;
  struct iactionelmchoice c[CHOICE_MAX];
  int cn;
};
typedef struct bullet Bullet;

struct bulletref {
  char label[LABEL_MAX];
  Params prms;
};
typedef struct bulletref BulletRef;

typedef union {
  struct bullet *b;
  struct bulletref *br;
} IBulletElmChoiceUnion;

struct ibulletelmchoice {
  int n;
  IBulletElmChoiceUnion u;
};
typedef struct ibulletelmchoice IBulletElmChoice;

struct fire {
  char label[LABEL_MAX];
  struct direction d;
  struct speed s;
  struct ibulletelmchoice b;
};
typedef struct fire Fire;

struct fireref {
  char label[LABEL_MAX];
  Params prms;
};
typedef struct fireref FireRef;

struct changespeed {
  struct speed s;
  Expression term;
};
typedef struct changespeed ChangeSpeed;

struct changedirection {
  struct direction d;
  Expression term;
};
typedef struct changedirection ChangeDirection;

struct horizontal {
  int type;
  Expression num;
};
typedef struct horizontal Horizontal;

struct vertical {
  int type;
  Expression num;
};
typedef struct vertical Vertical;

struct accel {
  struct horizontal h;
  struct vertical v;
  Expression term;
};
typedef struct accel Accel;

struct wait {
  Expression num;
};
typedef struct wait Wait;

struct vanish {
  int dummy;
};
typedef struct vanish Vanish;

struct actionref {
  char label[LABEL_MAX];
  Params prms;
};
typedef struct actionref ActionRef;

typedef union {
  struct repeat *rp;
  struct fire *f;
  struct fireref *fr;
  struct changespeed *cs;
  struct changedirection *cd;
  struct accel *ac;
  struct wait *w;
  struct vanish *v;
  struct action *a;
  struct actionref *ar;
} IActionChoiceUnion;

struct iactionchoice {
  int n;
  IActionChoiceUnion u;
};
typedef struct iactionchoice IActionChoice;

struct action {
  char label[LABEL_MAX];
  struct iactionchoice c[CHOICE_MAX];
  int cn;
};
typedef struct action Action;

typedef union {
  IActionChoice *iac;
  IActionElmChoice *iaec;
} IActionStackUnion;

typedef struct {
  int n;
  IActionStackUnion u;
  int *iaIdx;
} IActionStack;

#define TOP_MAX 4

typedef struct {
  Action action[TOP_MAX];
  Bullet bullet[TOP_MAX];
  Fire fire[TOP_MAX];
  int actIdx, bltIdx, frIdx;
  Action *topAction[TOP_MAX];
  int topActIdx;
} BulletML;
 
void loadBulletML(BulletML *bulletml, char *psdStr);
void initBulletMLParser();
#endif
