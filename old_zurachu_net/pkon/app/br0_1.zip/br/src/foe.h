/*
 * $Id: foe.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Battery/Bullet data.
 */
#ifndef FOE_H_
#define FOE_H_

#include "bmlprs.h"
#include "bmlmng.h"

#define DEFAULT_SPEED_DOWN_BULLETS_NUM 150

#define BULLET_COLOR_NUM 4
#define BULLET_TYPE_NUM 3

extern int processSpeedDownBulletsNum;
extern int nowait;

#include "vector.h"
#include "bmlprs.h"
#include "bmlmng.h"
#include "ship.h"

#define MORPH_PATTERN_MAX 4

#define BATTERY 0
#define ACTIVE_BULLET 1
#define BULLET 2

struct foe {
  Vector pos, vel, ppos, mv;
  int d, spd;
  int rank;
  int spc;
  int cnt, cntTotal;
  int fireCnt;
  BulletMLState state;

  BulletML *morph[MORPH_PATTERN_MAX];
  int morphCnt;
  int morphRank;
  int speedRank;

  int shapeType;

  struct limiter *limiter;

  int idx;
};

typedef struct foe Foe;

Foe* addFoeBattery(int x, int y, int rank, int d, int spd, int xReverse, 
		   BulletML *morph[], 
		   int morphCnt, int morphHalf, int morphRank, int speedRank,
		   struct limiter *limiter,
		   BulletML *bulletml);
void addFoeActiveBullet(Foe *foe, int d, int spd, BulletMLState *state);
void addFoeNormalBullet(Foe *foe, int d, int spd);
void removeFoe(Foe *fe);
void removeFoeForced(Foe *fe);
void clearFoes();

void initFoes();
void closeFoes();
void moveFoes();
void drawBullets();
#endif
