/*
 * $Id: expression.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Turn an expression into RPN.
 */
#include "expression.h"
#include "genmcr.h"

static int stack[EXPRESSION_MAX*2];

static int calcOp(int op, int n1, int n2) {
  switch ( op ) {
  case PLUS:
    return n1 + n2;
  case MINUS:
    return n1 - n2;
  case MULTIPLE:
    return ((long)n1 * n2)>>BASE_SHIFT;
  case DIVISION:
    return ((long)n1<<BASE_SHIFT) / n2;
  case MODULO:
    return n1 % n2;
  }
  return 0;
}

int evalExpression(Expression *ep, int *prms, int rank) {
  int stkIdx = 0;
  int i;
  for ( i=0 ; i<ep->idx ; i++ ) {
    switch ( ep->opr[i] ) {
    case STACK_NUM:
      stack[stkIdx] = ep->num[i];
      stkIdx++;
      break;
    case STACK_RAND:
      stack[stkIdx] = randN(BASE_MAG);
      stkIdx++;
      break;
    case STACK_RANK:
      stack[stkIdx] = rank;
      stkIdx++;
      break;
    default:
      if ( ep->opr[i] >= STACK_VARIABLE ) {
	stack[stkIdx] = prms[ep->opr[i]-STACK_VARIABLE];
	stkIdx++;
      } else {
	stack[stkIdx-2] = calcOp(ep->opr[i], stack[stkIdx-2], stack[stkIdx-1]);
	stkIdx--;
      }
      break;
    }
  }
  return stack[0];
}
