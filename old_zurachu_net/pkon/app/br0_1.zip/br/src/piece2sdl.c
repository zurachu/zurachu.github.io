/*
 * $Id: piece2sdl.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2001 Kenta Cho. All rights reserved.
 */

/**
 * Piece to SDL.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "SDL.h"
#include "piece2sdl.h"

SDL_Surface *video, *layer;

static SDL_Rect layerRect;
Uint16 pitch;

LayerBit *buf;

SDL_Color pltTbl[5] = {{255,255,255}, {170,170,170}, {85,85,85}, {0,0,0}, {0,255,0}};

static Uint8 *keys;
static SDL_Joystick *stick;

static void setPalette() {
  SDL_SetColors(video, pltTbl, 0, 5);
  SDL_SetColors(layer, pltTbl, 0, 5);
}

void initSDL() {
  Uint8  video_bpp;
  Uint32 videoflags;
  SDL_PixelFormat *pfrm;

  /* Initialize SDL */
  if ( SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0 ) {
    fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
    exit(1);
  }
  atexit(SDL_Quit);

  video_bpp = BPP;
  //videoflags = SDL_DOUBLEBUF | SDL_HWSURFACE | SDL_FULLSCREEN | SDL_HWPALETTE;
  videoflags = SDL_DOUBLEBUF | SDL_HWSURFACE | SDL_HWPALETTE;

  if ( NULL == (video = 
	SDL_SetVideoMode
		  (SDL_WIDTH, SDL_HEIGHT, video_bpp, videoflags)) ) {
    fprintf(stderr, "Couldn't set video mode: %s\n", SDL_GetError());
    exit(1);
  }
  pfrm = video->format;
  if ( NULL == ( layer = SDL_CreateRGBSurface
		(SDL_SWSURFACE, LAYER_WIDTH, LAYER_HEIGHT, video_bpp,
		 pfrm->Rmask, pfrm->Gmask, pfrm->Bmask, pfrm->Amask)) ) {
      fprintf(stderr, "Couldn't create surface: %s\n", SDL_GetError());
      exit(1);
  }
  layerRect.x = (SDL_WIDTH-LAYER_WIDTH)/2;
  layerRect.y = (SDL_HEIGHT-LAYER_HEIGHT)/2;
  layerRect.w = LAYER_WIDTH;
  layerRect.h = LAYER_HEIGHT;
  pitch = layer->pitch/(video_bpp/8);
  buf = layer->pixels;

  setPalette();

  stick = SDL_JoystickOpen(0);

  SDL_WM_SetCaption(CAPTION, NULL);
  srand(SDL_GetTicks());
}

void closeScreen() {
  SDL_FreeSurface(layer);
}

void flipScreen() {
  SDL_BlitSurface(layer, NULL, video, &layerRect);
  SDL_Flip(video);
}

void clearLayer() {
  SDL_FillRect(layer, NULL, 0);
}


static PIECE_BMP *bmp;
static int dx, dy, dw, dh;

void pceLCDSetObject(void *dummy, PIECE_BMP *surface, int x, int y, 
		     int sx, int sy, int width, int height, int mode) {
  bmp = surface;
  dx = x; dy = y; dw = width; dh = height;
}

static int maskTbl[8] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
static int c1Tbl[4] = {0x80, 0x20, 0x08, 0x02};
static int c2Tbl[4] = {0x40, 0x10, 0x04, 0x01};

void pceLCDDrawObject(void *dummy) {
  int y, sy, x, c;
  LayerBit *vbi;
  int mc;
  int w = bmp->header.w;
  BYTE *bf, *mk;
  for ( y=0, sy=dy ; y<dh ; y++, sy++ ) {
    if ( sy < 0 || sy >= SCREEN_HEIGHT ) continue;
    vbi = vbuf + sy*SCREEN_WIDTH + dx; mc = 0;
    bf = bmp->buf + ((w*y)>>2); mk = bmp->mask + ((w*y)>>3);
    for ( x=dx ; x<dx+dw ; x++ ) {
      if ( x >= 0 && x < SCREEN_WIDTH && ( (*mk) & maskTbl[mc] ) != 0 ) {
	c = 0;
	if ( ( (*bf) & c1Tbl[mc&3] ) != 0 ) c+=2;
	if ( ( (*bf) & c2Tbl[mc&3] ) != 0 ) c++;
	*vbi = c;
      }
      vbi++;
      mc++; mc &= 7;
      if ( (mc&7) == 4 ) {
	bf++;
      }
      if ( (mc&7) == 0 ) {
	bf++; mk++;
      }
    }
  }
}

void pceLCDLine(long color, long x1, long y1, long x2, long y2) {
  long lx, ly;
  long ax, ay, x, y;
  long px, py, p1;
  int i;

  /*if ( x1 < 0 ) {
    if ( x2 < 0 ) return;
    y1 = (y1-y2)*(x2-0)/(x2-x1)+y2;
    x1 = 0;
  } else if ( x2 < 0 ) {
    y2 = (y2-y1)*(x1-0)/(x1-x2)+y1;
    x2 = 0;
  }
  if ( x1 > SCREEN_WIDTH-1 ) {
    if ( x2 > SCREEN_WIDTH-1 ) return;
    y1 = (y1-y2)*(x2-(SCREEN_WIDTH-1))/(x2-x1)+y2;
    x1 = SCREEN_WIDTH-1;
  } else if ( x2 > SCREEN_WIDTH-1 ) {
    y2 = (y2-y1)*(x1-(SCREEN_WIDTH-1))/(x1-x2)+y1;
    x2 = SCREEN_WIDTH-1;
  }

  if ( y1 < 0 ) {
    if ( y2 < 0 ) return;
    x1 = (x1-x2)*(y2-0)/(y2-y1)+x2;
    y1 = 0;
  } else if ( y2 < 0 ) {
    x2 = (x2-x1)*(y1-0)/(y1-y2)+x1;
    y2 = 0;
  }
  if ( y1 > SCREEN_HEIGHT-1 ) {
    if ( y2 > SCREEN_HEIGHT-1 ) return;
    x1 = (x1-x2)*(y2-(SCREEN_HEIGHT-1))/(y2-y1)+x2;
    y1 = SCREEN_HEIGHT-1;
  } else if ( y2 > SCREEN_HEIGHT-1 ) {
    x2 = (x2-x1)*(y1-(SCREEN_HEIGHT-1))/(y1-y2)+x1;
    y2 = SCREEN_HEIGHT-1;
    }*/

  lx = absN(x2 - x1);
  ly = absN(y2 - y1);

  if ( lx < ly ) {
    if ( ly == 0 ) ly++;
    ax = ((x2 - x1)<<16) / ly;
    ay = ((y2 - y1)>>16) | 1;
    x  = x1<<16;
    y  = y1;
    for ( i=ly ; i>=0 ; i--, x+=ax, y+=ay ){
      px = x>>16;
      p1 = y * SCREEN_WIDTH + px;
      if ( p1 >= 0 && p1 < SCREEN_WIDTH*SCREEN_HEIGHT ) vbuf[p1] = color;
    }
  } else {
    if ( lx == 0 ) lx++;
    ay = ((y2 - y1)<<16) / lx;
    ax = ((x2 - x1)>>16) | 1;
    x  = x1;
    y  = y1<<16;
    for ( i=lx ; i>=0 ; i--, x+=ax, y+=ay ) {
      py = y>>16;
      p1 = py * SCREEN_WIDTH + x;
      if ( p1 >= 0 && p1 < SCREEN_WIDTH*SCREEN_HEIGHT ) vbuf[p1] = color;
    }
  }  
}

void pceLCDPoint(long c, long x, long y) {
  if ( x >= 0 && x <SCREEN_WIDTH && y >= 0 && y < SCREEN_HEIGHT ) {
    vbuf[x+y*SCREEN_WIDTH] = c;
  }
}

void pceLCDPaint(long c, long x, long y, long w, long h) {
  int tx, tw;
  for ( ; h>=0 ; h--, y++ ) {
    tx = x; tw = w;
    for ( ; tw>=0 ; tw--, tx++ ) {
      vbuf[tx+y*SCREEN_WIDTH] = c;
    }
  }
}

unsigned char vbuf[SCREEN_WIDTH*SCREEN_HEIGHT];

void pceLCDTrans() {
  int x, y;
  LayerBit *vbi = vbuf;
  unsigned char *bi;
  for ( y=0 ; y<LAYER_HEIGHT ; y++ ) {
    bi = buf + y*pitch;
    for ( x=0 ; x<LAYER_WIDTH ; x++ ) {
      //vbi = vbuf + (x/5) + (y/5)*SCREEN_WIDTH;
      vbi = vbuf + x + y*SCREEN_WIDTH;
      *bi = *vbi;
      //vbi++; 
      bi++;
    }
  }
  flipScreen();
}


#define JOYSTICK_AXIS 16384

static int keyPressed = 0;

int pcePadGet() {
  int pad = 0;
  int x = 0, y = 0;
  int btn1 = 0, btn2 = 0, btn3 = 0, btn4 = 0;
  if ( stick != NULL ) {
    x = SDL_JoystickGetAxis(stick, 0);
    y = SDL_JoystickGetAxis(stick, 1);
    btn1 = SDL_JoystickGetButton(stick, 0);
    btn2 = SDL_JoystickGetButton(stick, 1);
    btn3 = SDL_JoystickGetButton(stick, 2);
    btn4 = SDL_JoystickGetButton(stick, 3);
  }
  if ( keys[SDLK_RIGHT] == SDL_PRESSED || keys[SDLK_KP6] == SDL_PRESSED || 
       x > JOYSTICK_AXIS ) pad |= (PAD_RI | TRG_RI);
  if ( keys[SDLK_LEFT] == SDL_PRESSED || keys[SDLK_KP4] == SDL_PRESSED || 
       x < -JOYSTICK_AXIS ) pad |= (PAD_LF | TRG_LF);
  if ( keys[SDLK_DOWN] == SDL_PRESSED || keys[SDLK_KP2] == SDL_PRESSED || 
       y > JOYSTICK_AXIS ) pad |= (PAD_DN | TRG_DN);
  if ( keys[SDLK_UP] == SDL_PRESSED ||  keys[SDLK_KP8] == SDL_PRESSED || 
       y < -JOYSTICK_AXIS ) pad |= (PAD_UP | TRG_UP);
  if ( keys[SDLK_z] == SDL_PRESSED || btn2 ) pad |= (PAD_B | TRG_B);
  if ( keys[SDLK_x] == SDL_PRESSED || btn1 ) pad |= (PAD_A | TRG_A);
  if ( keys[SDLK_ESCAPE] == SDL_PRESSED || btn4 ) pad |= (PAD_D | TRG_D);
  if ( keys[SDLK_x] == SDL_PRESSED || keys[SDLK_z] == SDL_PRESSED ||
       btn1 || btn2 || btn3 ) pad |= (PAD_C | TRG_C);
  if ( (pad&(PAD_A|PAD_B|PAD_C|PAD_D)) != 0 ) {
    if ( keyPressed ) {
      pad &= (PAD_RI|PAD_LF|PAD_DN|PAD_UP|PAD_A|PAD_B|PAD_C|PAD_D);
    }
    keyPressed = 1;
  } else {
    keyPressed = 0;
  }
  return pad;
}

unsigned long pceTimerGetCount() {
  return SDL_GetTicks();
}

static int interval = 0;

void pceAppSetProcPeriod(int itv) {
  interval = itv;
}

static int done = 1;

void pceAppReqExit(int c) {
  done = 0;
}

int main(int argc, char *argv[]) {
  int intNum = 0;
  long nowTick, prvTickCount, wc;
  SDL_Event event;

  initSDL();

  pceAppInit();

  prvTickCount = SDL_GetTicks();
  while ( done ) {
    SDL_PollEvent(&event);
    keys = SDL_GetKeyState(NULL);

    nowTick = SDL_GetTicks();
    wc = prvTickCount+interval-nowTick;
    if ( wc > 0 ) SDL_Delay(wc);
    prvTickCount = SDL_GetTicks();

    pceAppProc(intNum);
    
    intNum++;

    if ( keys[SDLK_ESCAPE] == SDL_PRESSED || event.type == SDL_QUIT ) done = 0;
  }

  pceAppExit();
  return 1;
}
