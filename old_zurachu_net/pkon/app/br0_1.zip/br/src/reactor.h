/*
 * $Id: reactor.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Reactor data.
 */
#include "media.h"
#include "expression.h"
#include "vector.h"

#define REACTOR_MAJOR_AXIS ((SCREEN_WIDTH *5/6)<<(BASE_SHIFT-1))
#define REACTOR_MINOR_AXIS ((SCREEN_HEIGHT*5/6)<<(BASE_SHIFT-1))

#define REACTOR_POS_NUM 16

extern Vector reactorPos[(REACTOR_POS_NUM+1)*2];
extern int reactorType;

void initReactorData();
void initReactor();
void setReactorPos(int rt1, int rt2, int c);
void beatReactor();
void drawReactor();
int hitReactor(int x, int y);
