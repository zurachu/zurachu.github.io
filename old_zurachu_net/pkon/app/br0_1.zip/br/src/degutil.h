/*
 * $Id: degutil.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2001 Kenta Cho. All rights reserved.
 */

/**
 * Changing the cordinate into the angle.
 */
#define SC_TABLE_SIZE 1024

extern int sctbl[SC_TABLE_SIZE+SC_TABLE_SIZE/4];

int getDeg(int x, int y);
int getDistance(int x, int y);
