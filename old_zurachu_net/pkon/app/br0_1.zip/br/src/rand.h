/*
 * $Id: rand.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Make random number function.
 */
unsigned long nextRand();
