/*
 * $Id: frag.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Fragments.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include "frag.h"
#include "genmcr.h"
#include "media.h"
#include "vector.h"
#include "degutil.h"
#include "ship.h"
#include "expression.h"
#include "gamemanager.h"

Frag frag[FRAG_MAX];

void initFrags() {
  int i;
  for ( i=0 ; i<FRAG_MAX ; i++ ) {
    frag[i].cnt = 0;
  }
}

static int fragIdx = FRAG_MAX;

static void addFrag(Vector *pos, Vector *vel) {
  int i;
  for ( i=0 ; i<FRAG_MAX ; i++ ) {
    fragIdx--; if ( fragIdx < 0 ) fragIdx = FRAG_MAX-1;
    if ( frag[fragIdx].cnt <= 0 ) break;
  }
  if ( i >= FRAG_MAX ) return;
  frag[fragIdx].pos = *pos;
  frag[fragIdx].vel = *vel;
  frag[fragIdx].cnt = 20 + randN(8);
}

void addFragsDeg(Vector *pos, int n, int bd, int bsp) {
  int i, d, sp;
  Vector vel;
  for ( i=0 ; i<n ; i++ ) {
    d = (bd+randNS(128))&(SC_TABLE_SIZE-1);
    sp = (bsp*(256+randNS(64)))>>8;
    vel.x = (sctbl[d]                *sp)>>8;
    vel.y = (sctbl[d+SC_TABLE_SIZE/4]*sp)>>8;
    addFrag(pos, &vel);
  }
}

void addFragsVel(Vector *pos, int n, int mx, int my) {
  int i;
  Vector vel;
  for ( i=0 ; i<n ; i++ ) {
    vel.x = (mx*(256+randNS(64)))>>8;
    vel.y = (my*(256+randNS(64)))>>8;
    addFrag(pos, &vel);
  }
}

void addFragsRnd(Vector *pos, int n, int mv) {
  int i;
  Vector vel;
  for ( i=0 ; i<n ; i++ ) {
    vel.x = (mv*randNS(256))>>8;
    vel.y = (mv*randNS(256))>>8;
    addFrag(pos, &vel);
  }
}

#define FRAG_ACQUIRE_WIDTH 120
#define FRAG_INHALE_WIDTH 450

void moveFrags() {
  int i, d;
  Frag *fr;
  for ( i=0 ; i<FRAG_MAX ; i++ ) {
    if ( frag[i].cnt <= 0 ) continue;
    fr = &(frag[i]);
    if ( ship.invCnt <= 0 ) {
      d = vctDist(&(ship.pos), &(fr->pos));
      if ( d < FRAG_ACQUIRE_WIDTH ) {
	addScore();
	playSeNow(PCM_BONUS, 1);
	fr->cnt = 0;
	continue;
      } else if ( d < FRAG_INHALE_WIDTH ) {
	fr->vel.x += (long)(ship.pos.x - fr->pos.x)*(FRAG_INHALE_WIDTH-d)>>12;
	fr->vel.y += (long)(ship.pos.y - fr->pos.y)*(FRAG_INHALE_WIDTH-d)>>12;
      }
    }
    fr->pos.x += fr->vel.x;
    fr->pos.y += fr->vel.y;
    fr->cnt--;
  }
}

void drawFrags() {
  int cx, cy;
  int i;
  Frag *fr;
  for ( i=0 ; i<FRAG_MAX ; i++ ) {
    if ( frag[i].cnt <= 0 ) continue;
    fr = &(frag[i]);
    cx = (fr->pos.x>>BASE_SHIFT) + SCREEN_WIDTH/2;
    cy = (fr->pos.y>>BASE_SHIFT) + SCREEN_HEIGHT/2;
    if ( cx > 0 && cx < SCREEN_WIDTH-1 && cy > 0 && cy < SCREEN_HEIGHT-1 ) {
      pceLCDPoint(3, cx, cy);
      pceLCDPoint(2, cx-1, cy-1);
      pceLCDPoint(2, cx+1, cy-1);
      pceLCDPoint(2, cx-1, cy+1);
      pceLCDPoint(2, cx+1, cy+1);
    }
  }
}
