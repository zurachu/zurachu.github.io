/*
 * $Id: rand.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Make random number.
 */
#include "rand.h"

#include <stdlib.h>

unsigned long nextRand() {
  return rand();
}
