/*
 * $Id: brgmng.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Barrage data.
 */
#ifndef BARRAGEMANAGER_H_
#define BARRAGEMANAGER_H_

#include "bmlprs.h"

extern BulletML *normalBarragePattern, *morphBarragePattern;
extern int normalBarragePatternNum, morphBarragePatternNum;

void initBarragemanager();
#endif
