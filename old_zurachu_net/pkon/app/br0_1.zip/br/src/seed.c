/*
 * $Id: seed.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Barrage seeds.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include "genmcr.h"
#include "brgmng.h"
#include "seed.h"
#include "degutil.h"
#include "reactor.h"
#include "gamemanager.h"
#include "shot.h"
#include "frag.h"

static Seed bseed[SEED_MAX];
static int seedIdx;

void initSeeds() {
  int i;
  for ( i=0 ; i<SEED_MAX ; i++ ) {
    bseed[i].shield = NOT_EXIST;
  }
  seedIdx = SEED_MAX;
}

static void setFoeBattery(Foe **btFoe, Attack *at, Limiter *lt) {
  BulletML *mrp[MORPH_PATTERN_MAX];
  int i;
  for ( i=0 ; i<MORPH_PATTERN_MAX ; i++ ) {
    mrp[i] = &(morphBarragePattern[at->morphIdx[i]]);
  }
  *btFoe = addFoeBattery(0, 0, at->rank, 512, 0, at->xReverse,
			 mrp,
			 at->morphCnt, at->morphHalf, at->morphRank, at->speedRank,
			 lt,
			 &(normalBarragePattern[at->barrageIdx]));
}

#define SEED_NORMAL_SIZE 16
#define SEED_SHIELD 8

void addSeed(Attack *at, int d) {
  int i;
  Seed *sd;
  for ( i=0 ; i<SEED_MAX ; i++ ) {
    seedIdx--; if ( seedIdx < 0 ) seedIdx = SEED_MAX-1;
    if ( bseed[seedIdx].shield == NOT_EXIST ) break;
  }
  if ( i >= SEED_MAX ) return;
  sd = &(bseed[seedIdx]);
  sd->attack = *at;
  sd->d = d; sd->md = randN(5)-2;
  sd->size = 0;
  sd->cnt = 0;
  sd->limiter.cnt = sd->limiter.on = 0;
  sd->shield = SEED_SHIELD;
  sd->d1 = sd->d2 = 0;
}

static int handleLimiter(Limiter *lt, int max, int cnt) {
  if ( !lt->on ) {
    if ( lt->cnt > max ) {
      lt->on = 1;
      lt->cnt /= 3; lt->cnt += 32;
    }
  }
  if ( (cnt&3) == 0 && lt->cnt > 0 ) {
    lt->cnt--;
    if ( lt->on && lt->cnt <= 0 ) {
      lt->on = 0; lt->cnt = 0;
    }
  }
  return lt->on;
}

static void removeSeed(Seed *sd) {
  if ( sd->foe ) removeFoeForced(sd->foe);
  sd->shield = NOT_EXIST;
}

void clearSeeds() {
  int i;
  for ( i=0 ; i<SEED_MAX ; i++ ) {
    if ( bseed[i].shield == NOT_EXIST ) continue;
    addFragsDeg(&(bseed[i].pos), 10, (bseed[i].d+SC_TABLE_SIZE/2)&(SC_TABLE_SIZE-1), 32);
    removeSeed(&(bseed[i]));
  }
}

int seedNum, seedDstCnt;

#define SEED_MD_MAX 5
#define SEED_GROW_TIME 8

#define SEED_SHOT_HIT_RANGE 200
#define SEED_SHIP_HIT_RANGE 128

void moveSeeds() {
  int i, j;
  Seed *sd;
  int ldi, ldo;
  seedNum = 0;
  for ( i=0 ; i<SEED_MAX ; i++ ) {
    if ( bseed[i].shield == NOT_EXIST ) continue;
    sd = &(bseed[i]);
    sd->d += sd->md;
    if ( randN(16) == 0 ) {
      sd->md += randN(2)*2-1;
      if ( sd->md > SEED_MD_MAX ) sd->md = SEED_MD_MAX;
      else if ( sd->md < -SEED_MD_MAX ) sd->md = -SEED_MD_MAX;
    }
    sd->d &= SC_TABLE_SIZE-1;
    ldi = sd->d>>6; ldi <<= 1;
    ldo = (sd->d&63);
    sd->pos.x = ((((reactorPos[ldi].x*(64-ldo) + reactorPos[ldi+1].x*ldo)>>6)*230)>>4);
    sd->pos.y = ((((reactorPos[ldi].y*(64-ldo) + reactorPos[ldi+1].y*ldo)>>6)*230)>>4);

    if ( sd->cnt == SEED_GROW_TIME ) {
      //setFoeBattery(&(sd->foe), &(sd->attack), &(sd->bs), &(sd->limiter));
      setFoeBattery(&(sd->foe), &(sd->attack), &(sd->limiter));
      if ( sd->foe == NULL ) {
	removeSeed(sd);
	continue;
      }
    } 
    if ( sd->cnt >= SEED_GROW_TIME ) {
      sd->foe->pos.x = sd->pos.x;
      sd->foe->pos.y = sd->pos.y;
      sd->foe->d = (SC_TABLE_SIZE-1 - sd->d)&(SC_TABLE_SIZE-1);
      switch ( reactorType ) {
      case 1:
	if ( sd->foe->d < 256 || sd->foe->d >= 768 ) {
	  sd->foe->d = 0;
	} else {
	  sd->foe->d = 512;
	}
	break;
      case 2:
	if ( sd->foe->d < 512 ) {
	  sd->foe->d = 256;
	} else {
	  sd->foe->d = 768;
	}
	break;
      }
      sd->foe->d <<= BASE_SHIFT;
    }
    handleLimiter(&(sd->limiter), gameStatus.limiterBulletsNum, sd->cnt);
    // Check if the shot hits the seed.
    for ( j=0 ; j<SHOT_MAX ; j++ ) {
      if ( shot[j].cnt == NOT_EXIST ) continue;
      if ( vctDist(&(sd->pos), &(shot[j].pos)) < SEED_SHOT_HIT_RANGE ) {
	shot[j].cnt = NOT_EXIST;
	sd->shield--;
	if ( sd->shield > 0 ) {
	  sd->size = 32;
	  sd->d1 += 64+randN(128);
	  sd->d2 += 64+randN(128);
	  addFragsDeg(&(sd->pos), 4, (sd->d+SC_TABLE_SIZE/2)&(SC_TABLE_SIZE-1), 24);
	  playSeNow(PCM_HIT, 2);
	} else {
	  addFragsDeg(&(sd->pos), 24, (sd->d+SC_TABLE_SIZE/2)&(SC_TABLE_SIZE-1), 32);
	  playSeNow(PCM_SDBRK, 2);
	  removeSeed(sd);
	  seedDstCnt++;
	  continue;
	}
      }
    }
    // Check if the seed hits the ship.
    if ( sd->cnt >= SEED_GROW_TIME && vctDist(&(sd->pos), &(ship.pos)) < SEED_SHIP_HIT_RANGE ) {
      destroyShip();
      break;
    }
    sd->d1 += 5; sd->d2 += 7;
    sd->d1 &= (SC_TABLE_SIZE-1); sd->d2 &= (SC_TABLE_SIZE-1);
    sd->size += (SEED_NORMAL_SIZE - sd->size)>>2;
    sd->cnt++;
    seedNum++;
  }
}

static const int enpb[][3] = {
  {1,1,1},{-1,1,1},{-1,-1,1},{1,-1,1},
  {1,1,-1},{-1,1,-1},{-1,-1,-1},{1,-1,-1},
};
static const int enpc[][4] = {
  {0,1,2,3},{4,5,6,7},{0,1,5,4},{1,2,6,5},{2,3,7,6},
};
static int enp[8][2];

void drawSeeds() {
  int i, j, k;
  Seed *sd;
  int size, d1, d2;
  int ty;
  int eci1, eci2;
  int x, y;

  for ( i=0 ; i<SEED_MAX ; i++ ) {
    if ( bseed[i].shield == NOT_EXIST ) continue;
    sd = &(bseed[i]);

    x = (sd->pos.x>>BASE_SHIFT) + SCREEN_WIDTH/2; 
    y = (sd->pos.y>>BASE_SHIFT) + SCREEN_HEIGHT/2;

    size = sd->size>>2;
    startDrawPolygon();
    d1 = sd->d1; d2 = sd->d2;
    for ( j=0 ; j<8 ; j++ ) {
      enp[j][0] = (enpb[j][0]*sctbl[d1+SC_TABLE_SIZE/4] -
                   enpb[j][1]*sctbl[d1]) * size;
      ty        = (enpb[j][0]*sctbl[d1] +
                   enpb[j][1]*sctbl[d1+SC_TABLE_SIZE/4]);
      enp[j][1] = (((ty        *sctbl[d2+SC_TABLE_SIZE/4])>>8) -
                     enpb[j][2]*sctbl[d2]) * size;
      enp[j][0] >>= 8;
      enp[j][1] >>= 8;
    }
    for ( j=0 ; j<5 ; j++ ) {
      for ( k=0 ; k<4 ; k++ ) {
        eci1 = enpc[j][k];
        eci2 = enpc[j][(k+1)&3];
        scanEdge(x+enp[eci1][0], y+enp[eci1][1],
		 x+enp[eci2][0], y+enp[eci2][1]);
      }
    }
    drawPolygon(3, 1);
  }
}
