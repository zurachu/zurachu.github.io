/*
 * $Id: br.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Barrage Reactor bootstrap.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#include <time.h>
#endif

#include <string.h>
#include <stdlib.h>

#include "br.h"
#include "media.h"
#include "degutil.h"
#include "brgmng.h"
#include "foe.h"
#include "gamemanager.h"
#include "ship.h"
#include "shot.h"
#include "seed.h"
#include "reactor.h"
#include "frag.h"
#include "rand.h"

void initTitle() {
  gameStatus.type = TITLE; 
  gameStatus.cnt = 0;
  initReactor();
}

void initInGame() {
  gameStatus.type = IN_GAME; 
  gameStatus.cnt = 0;

  initFoes();
  initShip();
  initShots();
  initSeeds();
  initFrags();
  initReactor();

  startBGM(PCM_R1);
  startGame();
}

void initGameover() {
  gameStatus.type = GAMEOVER;
  gameStatus.cnt = 0;
  stopBGM();
  startGameover();
}

static void moveTitle() {
  moveGamemanager();
  drawReactor();
  drawGamemanager();
}

static void moveGame() {
  moveGamemanager();
  moveSeeds();
  moveFoes();
  moveShip();
  moveShots();
  moveFrags();
  drawReactor();
  drawSeeds();
  drawShots();
  drawFrags();
  drawShip();
  drawBullets();
  drawGamemanager();
}

static void moveGameover() {
  moveGamemanager();
  moveFrags();
  drawReactor();
  drawFrags();
  drawGamemanager();
}

void pceAppInit() {
  // Randomize.
#ifndef _PIECE2SDL
  PCETIME time;
  pceTimeGet(&time);
  srand(time.s100 + time.ss*100);
#else
  time_t timer;
  time(&timer);
  srand(timer);  
#endif
  //setSeed(rand()*2147483647);

  // No pad auto repeat.
#ifndef _PIECE2SDL
  while(pcePadGet()) pcePadGetProc();
  pcePadSetTrigMode(PP_MODE_SINGLE);

  pceLCDDispStop();
  pceLCDSetBuffer(vbuf);
#endif

  saveWaveAtt();
  initSound();

  initBarragemanager();
  initBulletMLManager();
  initReactorData();
  initGamemanager();

  initTitle();

  pceAppSetProcPeriod(INTERVAL);
#ifndef _PIECE2SDL
  pceLCDDispStart();
#endif
}

void pceAppProc(int c) {
  playBGM();
  clearScreen();

  switch ( gameStatus.type ) {
  case TITLE:
    moveTitle();
    break;
  case IN_GAME:
    moveGame();
    break;
  case GAMEOVER:
    moveGameover();
    break;
  }

  // Exit application when TRG_D(select) is pressed.
  if ( pcePadGet() & TRG_D ) {
    pceAppReqExit(1);
  }
  pceLCDTrans();
}

void pceAppExit() {
  saveHiScore();
  stopSe();
  loadWaveAtt();
}
