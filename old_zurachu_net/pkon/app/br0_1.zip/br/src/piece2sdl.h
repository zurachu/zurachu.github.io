/*
 * $Id: piece2sdl.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2001 Kenta Cho. All rights reserved.
 */

/**
 * Piece to SDL header file.
 *
 * @version $Revision: 1.1.1.1 $
 */
#include "genmcr.h"
#include "SDL.h"

#define CAPTION "Barrage Reactor"

//#define SDL_WIDTH 640
//#define SDL_HEIGHT 480
#define SDL_WIDTH 128
#define SDL_HEIGHT 88

//#define LAYER_WIDTH 640
//#define LAYER_HEIGHT 440
#define LAYER_WIDTH 128
#define LAYER_HEIGHT 88

#define LayerBit Uint8
#define BPP 8

extern LayerBit *buf;
extern Uint16 pitch;


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 88

extern unsigned char vbuf[SCREEN_WIDTH*SCREEN_HEIGHT];

#define PAD_RI 0x01
#define PAD_LF 0x02
#define PAD_DN 0x04
#define PAD_UP 0x08
#define PAD_B  0x10
#define PAD_A  0x20
#define PAD_D  0x40
#define PAD_C  0x80

#define TRG_RI 0x0100
#define TRG_LF 0x0200
#define TRG_DN 0x0400
#define TRG_UP 0x0800
#define TRG_B  0x1000
#define TRG_A  0x2000
#define TRG_D  0x4000
#define TRG_C  0x8000

#define PAD_START PAD_C
#define TRG_START TRG_C

#define PAD_SELECT PAD_D
#define TRG_SELECT TRG_D

//dummy
#define DRAW_OBJECT int*
#define DRW_NOMAL 0

typedef unsigned long DWORD;
typedef unsigned char BYTE;

typedef struct {
	DWORD	head;
	DWORD	fsize;
	BYTE	bpp;
	BYTE	mask;
	short	w;
	short	h;
	DWORD	buf_size;
}PBMP_FILEHEADER;

typedef struct{	//2BIT BMP + 1BIT MASK
	PBMP_FILEHEADER	header;
	BYTE			*buf;
	BYTE			*mask;
}PIECE_BMP;

void initScreen();
void closeScreen();
void flipScreen();
void clearLayer();
void pceLCDSetObject(void *dummy, PIECE_BMP *surface, int x, int y, 
		     int sx, int sy, int width, int height, int mode);
void pceLCDDrawObject(void *dummy);
void pceLCDLine(long color, long x1, long y1, long x2, long y2);
void pceLCDPoint(long c, long x, long y);
void pceLCDPaint(long c, long x, long y, long w, long h);
void pceLCDTrans();
void pceAppSetProcPeriod(int itv);
unsigned long pceTimerGetCount();
int pcePadGet();
void pceAppReqExit(int c);

void pceAppInit();
void pceAppProc(int c);
void pceAppExit();
