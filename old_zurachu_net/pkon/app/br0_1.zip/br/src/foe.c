/*
 * $Id: foe.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Handle batteries/bullets.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include "foe.h"
#include "genmcr.h"
#include "media.h"
#include "vector.h"
#include "degutil.h"
#include "bmlmng.h"
#include "ship.h"
#include "reactor.h"
#include "seed.h"
#include "gamemanager.h"
#include "shot.h"
#include "frag.h"

#define FOE_MAX 64

static Foe foe[FOE_MAX];

void removeFoeForced(Foe *fe) {
  fe->spc = NOT_EXIST;
  deleteActions(&(fe->state));
}

void removeFoe(Foe *fe) {
  if ( fe->spc == BATTERY ) return;
  removeFoeForced(fe);
}

void initFoes() {
  int i;
  for ( i=0 ; i<FOE_MAX ; i++ ) {
    foe[i].idx = i;
    removeFoeForced(&(foe[i]));
  }
}

void closeFoes() {
  int i;
  for ( i=0 ; i<FOE_MAX ; i++ ) {
    if ( foe[i].spc != NOT_EXIST ) deleteActions(&(foe[i].state));
  }
}

static int foeIdx = FOE_MAX;

static Foe* getNextFoe() {
  int i;
  for ( i=0 ; i<FOE_MAX ; i++ ) {
    foeIdx--; if ( foeIdx < 0 ) foeIdx = FOE_MAX-1;
    if ( foe[foeIdx].spc == NOT_EXIST ) break;
  }
  if ( i >= FOE_MAX ) return NULL;
  return &(foe[foeIdx]);
}

static Foe* addFoe(Foe *foe, int d, int spd) {
  Foe *fe;
  int idx;
  if ( foe->limiter->on && foe->spc == BATTERY ) return NULL;
  fe = getNextFoe();
  if ( !fe ) return NULL;
  idx = fe->idx;
  *fe = *foe;
  fe->idx = idx;
  fe->ppos = fe->pos;
  fe->vel.x = fe->vel.y = 0;
  fe->mv.x = fe->mv.y = 0;
  fe->cnt = 0;
  fe->d = d; fe->spd = spd;
  fe->shapeType = 2;
  fe->limiter->cnt++;
  fe->spc = BULLET;
  return fe;
}

Foe* addFoeBattery(int x, int y, int rank, int d, int spd, int xReverse, 
		   BulletML *morph[], 
		   int morphCnt, int morphHalf, int morphRank, int speedRank,
		   struct limiter *limiter,
		   BulletML *bulletml) {
  Foe foe;
  Foe *fe;
  int i;
  foe.pos.x = x; foe.pos.y = y;
  foe.rank = rank;
  foe.rank = BASE_MAG/4;
  for ( i=0 ; i<MORPH_PATTERN_MAX ; i++ ) {
    foe.morph[i] = morph[i];
  }
  foe.morphCnt = morphCnt;
  foe.morphRank = morphRank;
  foe.speedRank = speedRank;
  foe.limiter = limiter;
  foe.cntTotal = 0;
  fe = addFoe(&foe, d, spd);
  if ( !fe ) return NULL;
  if ( !setTopActions(fe, bulletml) ) {
    removeFoeForced(fe);
    return NULL;
  }
  fe->spc = BATTERY;
  fe->fireCnt = randN(2);
  return fe;
}

void addFoeActiveBullet(Foe *foe, int d, int spd, BulletMLState *state) {
  int i;
  Foe *fe;
  fe = addFoe(foe, d, spd);
  if ( !fe ) return;
  fe->state.bulletml = state->bulletml;
  fe->state.actIdx = state->actIdx;
  for ( i=0 ; i<fe->state.actIdx ; i++ ) {
    fe->state.action[i] = state->action[i];
    fe->state.action[i]->state = &(fe->state);
    fe->state.action[i]->foe = fe;
  }

  fe->spc = ACTIVE_BULLET;
  if ( fe->morphCnt > 0 ) fe->shapeType = 0;
  else                    fe->shapeType = 1;
}

void addFoeNormalBullet(Foe *foe, int d, int spd) {
  Foe *fe;
  if ( foe->morphCnt > 0 ) {
    Foe *fe, mf;
    mf = *foe;
    mf.morphCnt--;
    mf.morphRank *= 0.85;
    fe = addFoe(&mf, d, spd);
    if ( !fe ) return;
    if ( !setTopActions(fe, foe->morph[mf.morphCnt&(MORPH_PATTERN_MAX-1)]) ) {
      removeFoeForced(fe);
      return;
    }
    fe->spc = ACTIVE_BULLET;
    if ( fe->morphCnt > 0 ) fe->shapeType = 0;
    else                    fe->shapeType = 1;
    return;
  }
  fe = addFoe(foe, d, spd);
  if ( !fe ) return;
  fe->state.actIdx = 0;
  fe->spc = ACTIVE_BULLET;
  fe->shapeType = 2;
}

void clearFoes() {
  int i;
  Foe *fe;
  for ( i=0 ; i<FOE_MAX ; i++ ) {
    if ( foe[i].spc == NOT_EXIST ) continue;
    fe = &(foe[i]);
    removeFoeForced(fe);
  }
}

#define SHIP_HIT_WIDTH 300*300
#define SLOW_MOVE 8
#define SLOW_MOVE_VANISH_CNT 60
#define LIMITER_VANISH_CNT 8

#define BULLET_SHOT_HIT_RANGE 128
#define BULLET_SHIP_HIT_RANGE 48

void moveFoes() {
  int i, j;
  Foe *fe;
  int foeNum = 0;
  int mx, my;

  for ( i=0 ; i<FOE_MAX ; i++ ) {
    if ( foe[i].spc == NOT_EXIST ) continue;
    fe = &(foe[i]);
    if ( fe->state.actIdx > 0 ) {
      if ( fe->spc == BATTERY ) {
	if ( isAllActionFinished(&(fe->state)) ) {
	  rewindActions(&(fe->state));
	}
      }
      runActions(&(fe->state));
      if ( fe->spc == NOT_EXIST ) {
	continue;
      }
    }
    fe->cnt++;
    fe->ppos = fe->pos;
    mx = (int)(( (((long)sctbl[(fe->d>>BASE_SHIFT)]    *fe->spd)>>(8+SPEED_BASE_SHIFT)) 
		 + (fe->vel.x>>SPEED_BASE_SHIFT)) );
    my = (int)((-(((long)sctbl[(fe->d>>BASE_SHIFT)+256]*fe->spd)>>(8+SPEED_BASE_SHIFT)) 
		 + (fe->vel.y>>SPEED_BASE_SHIFT)) );
    mx = (mx*fe->speedRank)>>BASE_SHIFT;
    my = (my*fe->speedRank)>>BASE_SHIFT;
    fe->mv.x = mx;
    fe->mv.y = my;
    fe->pos.x += fe->mv.x;
    fe->pos.y += my;

    if ( fe->spc != BATTERY && gameStatus.type == IN_GAME ) {
      // Check if the shot hits the bullet.
      for ( j=0 ; j<SHOT_MAX ; j++ ) {
	if ( shot[j].cnt == NOT_EXIST ) continue;
	if ( vctDist(&(fe->pos), &(shot[j].pos)) < BULLET_SHOT_HIT_RANGE ) {
	  addFragsVel(&(fe->pos), 5, fe->mv.x, my);
	  playSeNow(PCM_BLBRK, 1);
	  shot[j].cnt = NOT_EXIST;
	  removeFoe(fe);
	  continue;
	}
      }
      // Check if the bullet hits the ship.
      if ( vctDist(&(fe->pos), &(ship.pos)) < BULLET_SHIP_HIT_RANGE ) {
	destroyShip();
	break;
      }
    }
    if ( hitReactor(fe->ppos.x, fe->ppos.y) ) {
      removeFoe(fe);
      continue;
    }
    foeNum++;
  }
}

static int foeShape[3][9] = {
  {4, -350,6, -100,6, 100,6, 250,6},
  {4, -400,6, -50,6, 50,6, 400,6},
  {3, -341,6, 0,6, 341,6},
};

void drawBullets() {
  int i, j;
  Foe *fe;
  int cx, cy, cd, sz, d;
  int x[4], y[4];
  int *fs;
  for ( i=0 ; i<FOE_MAX ; i++ ) {
    if ( foe[i].spc == NOT_EXIST || foe[i].spc == BATTERY ) continue;
    fe = &(foe[i]);
    cx = (fe->pos.x>>BASE_SHIFT) + SCREEN_WIDTH/2;
    cy = (fe->pos.y>>BASE_SHIFT) + SCREEN_HEIGHT/2;
    cd = 1023 + 512 - getDeg(fe->pos.x - fe->ppos.x, fe->pos.y - fe->ppos.y);
    fs = foeShape[fe->shapeType];
    for ( j=0 ; j<fs[0] ; j++ ) {
      sz = fs[j*2+2];
      d = cd + fs[j*2+1];
      d &= (SC_TABLE_SIZE-1);
      x[j] = cx + (sctbl[d]>>sz); y[j] = cy + (sctbl[d+SC_TABLE_SIZE/4]>>sz);
      switch ( j ) {
      case 0:
	drawLine(3, cx, cy, x[j], y[j]);
	break;
      default:
	drawLine(3, x[j-1], y[j-1], x[j], y[j]);
	break;
      }
    }
    drawLine(3, cx, cy, x[j-1], y[j-1]);
  }
}
