/*
 * $Id: shot.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * Handle players shots.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include "shot.h"
#include "genmcr.h"
#include "media.h"
#include "vector.h"
#include "degutil.h"
#include "reactor.h"
#include "expression.h"

Shot shot[SHOT_MAX];

void initShots() {
  int i;
  for ( i=0 ; i<SHOT_MAX ; i++ ) {
    shot[i].cnt = NOT_EXIST;
  }
}

static int shotIdx = SHOT_MAX;

#define SHOT_SPEED 64

void addShot(Vector *pos, int d) {
  int i;
  Shot *st;
  for ( i=0 ; i<SHOT_MAX ; i++ ) {
    shotIdx--; if ( shotIdx < 0 ) shotIdx = SHOT_MAX-1;
    if ( shot[shotIdx].cnt == NOT_EXIST ) break;
  }
  if ( i >= SHOT_MAX ) return;
    st = &(shot[shotIdx]);
  st->pos = *pos;
  st->d = d;
  st->cnt = 0;
  st->pos.x += (sctbl[st->d]                 * SHOT_SPEED) >> 7;
  st->pos.y += (sctbl[st->d+SC_TABLE_SIZE/4] * SHOT_SPEED) >> 7;
}

void moveShots() {
  int i;
  Shot *st;
  for ( i=0 ; i<SHOT_MAX ; i++ ) {
    if ( shot[i].cnt == NOT_EXIST ) continue;
    st = &(shot[i]);
    st->pos.x += (sctbl[st->d]                 * SHOT_SPEED) >> 8;
    st->pos.y += (sctbl[st->d+SC_TABLE_SIZE/4] * SHOT_SPEED) >> 8;
    st->cnt++;
    if ( hitReactor(st->pos.x, st->pos.y) ) {
      st->cnt = NOT_EXIST;
      continue;
    }
  }
}

void drawShots() {
  int cx, cy, ox, oy;
  int i;
  Shot *st;
  for ( i=0 ; i<SHOT_MAX ; i++ ) {
    if ( shot[i].cnt == NOT_EXIST ) continue;
    st = &(shot[i]);
    cx = (st->pos.x>>BASE_SHIFT) + SCREEN_WIDTH/2;
    cy = (st->pos.y>>BASE_SHIFT) + SCREEN_HEIGHT/2;
    ox = sctbl[st->d]                >>6;
    oy = sctbl[st->d+SC_TABLE_SIZE/4]>>6;
    drawLine(2, cx-ox, cy-oy, cx+ox, cy+oy);
  }
}

