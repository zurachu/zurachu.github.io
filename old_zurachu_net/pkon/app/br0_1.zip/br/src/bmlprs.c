/*
 * $Id: bmlprs.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * BulletML parser.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#define malloc(P) pceHeapAlloc(P)
#else
#include "piece2sdl.h"
#include <stdlib.h>
#endif

#include <string.h>

#include "bmlprs.h"

#define DEPTH_MAX 8

static IActionStack ias[DEPTH_MAX];
static int iasIdx;
static IActionChoice *iac;
static int *iacIdx;
static IActionElmChoice *iaec;
static int *iaecIdx;

static int rpIaecIdx;
static Vertical *vt;
static Horizontal *hz;
static Speed *sp;
static Direction *dr;
static IBulletElmChoice *ibec;
static Params *prms;
static Expression *times;
static Expression *term;
static Expression *num;

static BulletML *bm;
static int elmLvl;

static Vanish vanish;

static Action* newAction() {
  return (Action*)malloc(sizeof(Action));
}

static ActionRef* newActionRef() {
  return (ActionRef*)malloc(sizeof(ActionRef));
}

static Bullet* newBullet() {
  Bullet *bl = (Bullet*)malloc(sizeof(Bullet));
  bl->d.num.idx = 0;
  bl->s.num.idx = 0;
  return bl;
}

static BulletRef* newBulletRef() {
  return (BulletRef*)malloc(sizeof(BulletRef));
}

static Fire* newFire() {
  Fire *f = (Fire*)malloc(sizeof(Fire));
  f->d.num.idx = 0;
  f->s.num.idx = 0;
  return f;
}

static FireRef* newFireRef() {
  return (FireRef*)malloc(sizeof(FireRef));
}

static Repeat* newRepeat() {
  return (Repeat*)malloc(sizeof(Repeat));
}

static Wait* newWait() {
  return (Wait*)malloc(sizeof(Wait));
}

static ChangeDirection* newChangeDirection() {
  return (ChangeDirection*)malloc(sizeof(ChangeDirection));
}

static ChangeSpeed* newChangeSpeed() {
  return (ChangeSpeed*)malloc(sizeof(ChangeSpeed));
}

static Accel* newAccel() {
  Accel *acc = (Accel*)malloc(sizeof(Accel));
  acc->h.num.idx = 0;
  acc->v.num.idx = 0;
  return acc;
}

static void init() {
  bm->actIdx = bm->bltIdx = bm->frIdx = 0;
  elmLvl = -1;
}

static char *psdStr;
static int psIdx;

#define START_ELEMENT 1
#define END_ELEMENT 2
#define CHARACTERS 3
#define XML_END 4
#define ATTRIBUTE 5
#define ATTRIBUTE_NULL 6
#define EXPRESSION 7

static char *att;

static char* getAtt() {
  char c;
  c = psdStr[psIdx]; psIdx++;
  if ( c == ATTRIBUTE_NULL ) return NULL;
  att = &(psdStr[psIdx]); 
  psIdx += strlen(att)+1;
  return att;
}

static int getType(char *tp) {
  if ( tp == NULL ) return AIM;
  else if ( strcmp(tp, "absolute") == 0 ) return ABSOLUTE;
  else if ( strcmp(tp, "relative") == 0 ) return RELATIVE;
  else if ( strcmp(tp, "sequence") == 0 ) return SEQUENCE;
  else return AIM;
}

static int getTypeSpeed(char *tp) {
  if ( tp == NULL ) return ABSOLUTE;
  else if ( strcmp(tp, "relative") == 0 ) return RELATIVE;
  else if ( strcmp(tp, "sequence") == 0 ) return SEQUENCE;
  else return ABSOLUTE;
}

void StartElement(char *qName) {
  if ( strcmp(qName, "action") == 0 ) {
    char *lb = getAtt();
    if ( elmLvl == 0 ) {
      if ( lb != NULL ) strcpy(bm->action[bm->actIdx].label, lb);
      iac = bm->action[bm->actIdx].c;
      iacIdx = &(bm->action[bm->actIdx].cn);
      *iacIdx = -1;
      bm->actIdx++;
      iasIdx = 0;
      ias[iasIdx].n = IACTIONCHOICE;
    } else {
      if ( ias[iasIdx].n == IACTIONCHOICE ) {
	int ti;
	(*iacIdx)++;
	iac[*iacIdx].n = ACTION;
	iac[*iacIdx].u.a = newAction();
	if ( lb != NULL ) strcpy(iac[*iacIdx].u.a->label, lb);
	ias[iasIdx].u.iac = iac;
	ias[iasIdx].iaIdx = iacIdx;
	iasIdx++;
	ias[iasIdx].n = IACTIONCHOICE;
	ti = *iacIdx;
	iacIdx = &(iac[*iacIdx].u.a->cn);
	iac = iac[ti].u.a->c;
	*iacIdx = -1;
      } else {
	(*iaecIdx)++;
	iaec[*iaecIdx].n = ACTION;
	iaec[*iaecIdx].u.a = newAction();
	if ( lb != NULL ) strcpy(iaec[*iaecIdx].u.a->label, lb);
	ias[iasIdx].u.iaec = iaec;
	ias[iasIdx].iaIdx = iaecIdx;
	iasIdx++;
	ias[iasIdx].n = IACTIONCHOICE;
	iacIdx = &(iaec[*iaecIdx].u.a->cn);
	iac = iaec[*iaecIdx].u.a->c;
	*iacIdx = -1;
      }
    }
  } else if ( strcmp(qName, "actionRef") == 0 ) {
    char *lb = getAtt();
    if ( ias[iasIdx].n == IACTIONCHOICE ) {
      (*iacIdx)++;
      iac[*iacIdx].n = ACTION_REF;
      iac[*iacIdx].u.ar = newActionRef();
      prms = &(iac[*iacIdx].u.ar->prms);
      prms->idx = 0;
      strcpy(iac[*iacIdx].u.ar->label, lb);
    } else {
      (*iaecIdx)++;
      iaec[*iaecIdx].n = ACTION_REF;
      iaec[*iaecIdx].u.ar = newActionRef();
      prms = &(iaec[*iaecIdx].u.ar->prms);
      prms->idx = 0;
      strcpy(iaec[*iaecIdx].u.ar->label, lb);
    }
  } else if ( strcmp(qName, "bullet") == 0 ) {
    char *lb = getAtt();
    if ( elmLvl == 0 ) {
      if ( lb != NULL ) strcpy(bm->bullet[bm->bltIdx].label, lb);
      dr = &(bm->bullet[bm->bltIdx].d);
      dr->num.idx = 0;
      sp = &(bm->bullet[bm->bltIdx].s);
      sp->num.idx = 0;
      iaec = bm->bullet[bm->bltIdx].c;
      iaecIdx = &(bm->bullet[bm->bltIdx].cn);
      *iaecIdx = -1;
      bm->bltIdx++;
      iasIdx = 0;
      ias[iasIdx].n = IACTIONELMCHOICE;
    } else {
      ibec->n = BULLET;
      ibec->u.b = newBullet();
      dr = &(ibec->u.b->d);
      sp = &(ibec->u.b->s);
      if ( lb != NULL ) strcpy(ibec->u.b->label, lb);
      if ( ias[iasIdx].n == IACTIONCHOICE ) {
	ias[iasIdx].u.iac = iac;
	ias[iasIdx].iaIdx = iacIdx;
      } else {
	ias[iasIdx].u.iaec = iaec;
	ias[iasIdx].iaIdx = iaecIdx;
      }
      iasIdx++;
      ias[iasIdx].n = IACTIONELMCHOICE;
      iaec = ibec->u.b->c;
      iaecIdx = &(ibec->u.b->cn);
      *iaecIdx = -1;
    }
  } else if ( strcmp(qName, "bulletRef") == 0 ) {
    char *lb = getAtt();
    ibec->n = BULLET_REF;
    ibec->u.br = newBulletRef();
    prms = &(ibec->u.br->prms);
    prms->idx = 0;
    strcpy(ibec->u.br->label, lb);
  } else if ( strcmp(qName, "fire") == 0 ) {
    char *lb = getAtt();
    if ( elmLvl == 0 ) {
      if ( lb != NULL ) strcpy(bm->fire[bm->frIdx].label, lb);
      dr = &(bm->fire[bm->frIdx].d);
      dr->num.idx = 0;
      sp = &(bm->fire[bm->frIdx].s);
      sp->num.idx = 0;
      ibec = &(bm->fire[bm->frIdx].b);
      bm->frIdx++;
      iasIdx = -1;
    } else {
      (*iacIdx)++;
      iac[*iacIdx].n = FIRE;
      iac[*iacIdx].u.f = newFire();
      if ( lb != NULL ) strcpy(iac[*iacIdx].u.f->label, lb);
      dr = &(iac[*iacIdx].u.f->d);
      sp = &(iac[*iacIdx].u.f->s);
      ibec = &(iac[*iacIdx].u.f->b);
    }
  } else if ( strcmp(qName, "fireRef") == 0 ) {
    char *lb = getAtt();
    (*iacIdx)++;
    iac[*iacIdx].n = FIRE_REF;
    iac[*iacIdx].u.fr = newFireRef();
    prms = &(iac[*iacIdx].u.fr->prms);
    prms->idx = 0;
    strcpy(iac[*iacIdx].u.fr->label, lb);
  } else if ( strcmp(qName, "direction") == 0 ) {
    dr->type = getType(getAtt());
  } else if ( strcmp(qName, "speed") == 0 ) {
    sp->type = getTypeSpeed(getAtt());
  } else if ( strcmp(qName, "repeat") == 0 ) {
    (*iacIdx)++;
    iac[*iacIdx].n = REPEAT;
    iac[*iacIdx].u.rp = newRepeat();
    times = &(iac[*iacIdx].u.rp->times);
    ias[iasIdx].u.iac = iac;
    ias[iasIdx].iaIdx = iacIdx;
    iasIdx++;
    ias[iasIdx].n = IACTIONELMCHOICE;
    iaecIdx = &rpIaecIdx;
    iaec = iac[*iacIdx].u.rp->a;
    *iaecIdx = -1;
  } else if ( strcmp(qName, "direction") == 0 ) {
    dr->type = getType(getAtt());
  } else if ( strcmp(qName, "speed") == 0 ) {
    sp->type = getTypeSpeed(getAtt());
  } else if ( strcmp(qName, "wait") == 0 ) {
    (*iacIdx)++;
    iac[*iacIdx].n = WAIT;
    iac[*iacIdx].u.w = newWait();
    num = &(iac[*iacIdx].u.w->num);
  } else if ( strcmp(qName, "changeDirection") == 0 ) {
    (*iacIdx)++;
    iac[*iacIdx].n = CHANGE_DIRECTION;
    iac[*iacIdx].u.cd = newChangeDirection();
    dr = &(iac[*iacIdx].u.cd->d);
    term = &(iac[*iacIdx].u.cd->term);
  } else if ( strcmp(qName, "changeSpeed") == 0 ) {
    (*iacIdx)++;
    iac[*iacIdx].n = CHANGE_SPEED;
    iac[*iacIdx].u.cs = newChangeSpeed();
    sp = &(iac[*iacIdx].u.cs->s);
    term = &(iac[*iacIdx].u.cs->term);
  } else if ( strcmp(qName, "vanish") == 0 ) {
    (*iacIdx)++;
    iac[*iacIdx].n = VANISH;
    iac[*iacIdx].u.v = &vanish;
  } else if ( strcmp(qName, "accel") == 0 ) {
    (*iacIdx)++;
    iac[*iacIdx].n = ACCEL;
    iac[*iacIdx].u.ac = newAccel();
    hz = &(iac[*iacIdx].u.ac->h);
    vt = &(iac[*iacIdx].u.ac->v);
    term = &(iac[*iacIdx].u.ac->term);
  } else if ( strcmp(qName, "horizontal") == 0 ) {
    hz->type = getTypeSpeed(getAtt());
    num = &(hz->num);
  } else if ( strcmp(qName, "vertical") == 0 ) {
    vt->type = getTypeSpeed(getAtt());
    num = &(vt->num);
  }
  elmLvl++;
}

/*static char elmChars[256];*/
static Expression ep;

void EndElement(char *qName) {
  if ( strcmp(qName, "direction") == 0 ) {
    /*parseExpression(&dr->num, elmChars);*/
    dr->num = ep;
  } else if ( strcmp(qName, "speed") == 0 ) {
    /*parseExpression(&sp->num, elmChars);*/
    sp->num = ep;
  } else if ( strcmp(qName, "wait") == 0 ) {
    /*parseExpression(num, elmChars);*/
    *num = ep;
  } else if ( strcmp(qName, "times") == 0 ) {
    /*parseExpression(times, elmChars);*/
    *times = ep;
  } else if ( strcmp(qName, "term") == 0 ) {
    /*parseExpression(term, elmChars);*/
    *term = ep;
  } else if ( strcmp(qName, "horizontal") == 0 ) {
    /*parseExpression(num, elmChars);*/
    *num = ep;
  } else if ( strcmp(qName, "vertical") == 0 ) {
    /*parseExpression(num, elmChars);*/
    *num = ep;
  } else if ( strcmp(qName, "param") == 0 ) {
    /*parseExpression(&(prms->prm[prms->idx]), elmChars);*/
    prms->prm[prms->idx] = ep;
    prms->idx++;
  } else if ( strcmp(qName, "action") == 0 || 
	      strcmp(qName, "bullet") == 0 || 
	      strcmp(qName, "repeat") == 0 ) {
    iasIdx--;
    if ( iasIdx >= 0 ) {
      if ( ias[iasIdx].n == IACTIONCHOICE ) {
	iac = ias[iasIdx].u.iac;
	iacIdx = ias[iasIdx].iaIdx;
      } else {
	iaec = ias[iasIdx].u.iaec;
	iaecIdx = ias[iasIdx].iaIdx;
      }
    }
    if ( strcmp(qName, "action") == 0 ) {
      (*iacIdx)++;
    } else if ( strcmp(qName, "bullet") == 0 ) {
      (*iaecIdx)++;
    }
  }
  elmLvl--;
}

/*void Characters(char *str) {
  strcpy(elmChars, str);
}*/

int ExpressionCharacters(char *str) {
  int i, idx = 0;
  long n;
  unsigned char uc1, uc2;
  ep.idx = str[idx]; idx++;
  for ( i=0 ; i<ep.idx ; i++ ) {
    uc1 = str[idx]; idx++;
    uc2 = str[idx]; idx++;
    n = uc1 + uc2*0x100;
    if ( n >= 32768 ) n -= 65536;
    ep.num[i] = (int)n;
    ep.opr[i] = str[idx]; idx++;
  }
  return idx;
}

void loadBulletML(BulletML *bulletml, char *data) {
  char c;
  char *str;
  int i;

  bm = bulletml;
  init();

  psdStr = data;
  psIdx = 0;
  for ( ; ; ) {
    c = psdStr[psIdx]; psIdx++;
    if ( c == XML_END ) break;
    str = &(psdStr[psIdx]); 
    switch ( c ) {
    case START_ELEMENT:
      psIdx += strlen(str)+1;
      StartElement(str);
      break;
    case END_ELEMENT:
      psIdx += strlen(str)+1;
      EndElement(str);
      break;
      /*case CHARACTERS:
      Characters(str);
      break;
      */
    case EXPRESSION:
      psIdx += ExpressionCharacters(str);
      break;
    }
  }

  /* Retrieve the actions which label starts with 'top'. */
  bm->topActIdx = 0;
  for ( i=0 ; i<bm->actIdx ; i++ ) {
    if ( strncmp(bm->action[i].label, "top", 3) == 0 ) {
      bm->topAction[bm->topActIdx] = &(bm->action[i]);
      bm->topActIdx++;
    }
  }
}
