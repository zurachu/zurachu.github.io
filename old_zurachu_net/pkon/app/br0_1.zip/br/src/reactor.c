/*
 * $Id: reactor.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Draw a reactor.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include <math.h>

int errno;

#include "reactor.h"
#include "genmcr.h"
#include "vector.h"
#include "media.h"
#include "degutil.h"

#define REACTOR_TYPE_NUM 3

static Vector reactorPosData[REACTOR_TYPE_NUM][(REACTOR_POS_NUM+1)*2];
Vector reactorPos[(REACTOR_POS_NUM+1)*2];
int reactorType;

void initReactorData() {
  int i, j;
  int x, y;
  for ( j=0 ; j<REACTOR_TYPE_NUM ; j++ ) {
    switch (j) {
    case 0:
      for ( i=0 ; i<5 ; i++ ) {
	x = (REACTOR_MAJOR_AXIS*sctbl[SC_TABLE_SIZE/4/4*i])>>8;
	y = (((REACTOR_MINOR_AXIS*REACTOR_MINOR_AXIS)>>8) * 
	     ((REACTOR_MAJOR_AXIS*REACTOR_MAJOR_AXIS)>>8) -
	     ((REACTOR_MINOR_AXIS*REACTOR_MINOR_AXIS)>>8)*((x*x)>>8)) /
	  ((REACTOR_MAJOR_AXIS*REACTOR_MAJOR_AXIS)>>8);
	y <<= 8;
	y = sqrt(y);
	x *= 1.1f; y *= 1.1f;
	x >>= BASE_SHIFT; y >>= BASE_SHIFT;
	reactorPosData[j][i*2].x     =  x; reactorPosData[j][i*2].y   =  y;
	if ( i > 0 ) {
	  reactorPosData[j][i*2-1].x =  x; reactorPosData[j][i*2-1].y =  y;
	}
	reactorPosData[j][(8-i)*2].x    =  x; reactorPosData[j][(8-i)*2].y    = -y;
	reactorPosData[j][(8-i)*2-1].x  =  x; reactorPosData[j][(8-i)*2-1].y  = -y;
	reactorPosData[j][(16-i)*2].x   = -x; reactorPosData[j][(16-i)*2].y   =  y;
	reactorPosData[j][(16-i)*2-1].x = -x; reactorPosData[j][(16-i)*2-1].y =  y;
	reactorPosData[j][(i+8)*2].x    = -x; reactorPosData[j][(i+8)*2].y    = -y;
	reactorPosData[j][(i+8)*2-1].x  = -x; reactorPosData[j][(i+8)*2-1].y  = -y;
      }
      break;
    case 1:
      for ( i=0 ; i<5 ; i++ ) {
	x = SCREEN_WIDTH/2/4 * i;
	y = (REACTOR_MINOR_AXIS*5/6) >> BASE_SHIFT;
	reactorPosData[j][i*2].x     =  x; reactorPosData[j][i*2].y   =  y;
	if ( i > 0 ) {
	  reactorPosData[j][i*2-1].x =  x; reactorPosData[j][i*2-1].y =  y;
	}
	reactorPosData[j][(8-i)*2].x    =  x; reactorPosData[j][(8-i)*2].y    = -y;
	if ( i < 4 ) {
	  reactorPosData[j][(8-i)*2-1].x  =  x; reactorPosData[j][(8-i)*2-1].y  = -y;
	}
	reactorPosData[j][(16-i)*2].x   = -x; reactorPosData[j][(16-i)*2].y   =  y;
	reactorPosData[j][(16-i)*2-1].x = -x; reactorPosData[j][(16-i)*2-1].y =  y;
	if ( i < 4 ) {
	  reactorPosData[j][(i+8)*2].x    = -x; reactorPosData[j][(i+8)*2].y    = -y;
	}
	reactorPosData[j][(i+8)*2-1].x  = -x; reactorPosData[j][(i+8)*2-1].y  = -y;
      }
      break;
    case 2:
      for ( i=0 ; i<5 ; i++ ) {
	x = (REACTOR_MAJOR_AXIS*3/4) -
	  (((REACTOR_MAJOR_AXIS/4)*sctbl[SC_TABLE_SIZE/4/4*i])>>8);
	x >>= BASE_SHIFT;
	y = SCREEN_HEIGHT/2/4 * (4-i);
	reactorPosData[j][i*2].x     =  x; reactorPosData[j][i*2].y   =  y;
	if ( i > 0 ) {
	  reactorPosData[j][i*2-1].x =  x; reactorPosData[j][i*2-1].y =  y;
	}
	reactorPosData[j][(8-i)*2].x    =  x; reactorPosData[j][(8-i)*2].y    = -y;
	reactorPosData[j][(8-i)*2-1].x  =  x; reactorPosData[j][(8-i)*2-1].y  = -y;
	reactorPosData[j][(16-i)*2].x   = -x; reactorPosData[j][(16-i)*2].y   =  y;
	reactorPosData[j][(16-i)*2-1].x = -x; reactorPosData[j][(16-i)*2-1].y =  y;
	reactorPosData[j][(i+8)*2].x    = -x; reactorPosData[j][(i+8)*2].y    = -y;
	if ( i > 0 ) {
	  reactorPosData[j][(i+8)*2-1].x  = -x; reactorPosData[j][(i+8)*2-1].y  = -y;
	}
      }
      break;
    }
  }
}

void setReactorPos(int rt1, int rt2, int c) {
  int i;
  for ( i=0 ; i<(REACTOR_POS_NUM+1)*2 ; i++ ) {
    reactorPos[i].x = (reactorPosData[rt1][i].x*(256-c) + reactorPosData[rt2][i].x*c)>>8;
    reactorPos[i].y = (reactorPosData[rt1][i].y*(256-c) + reactorPosData[rt2][i].y*c)>>8;
  }
}

static int reactorBeatCount;

#define REACTOR_EDGE_NUM 4
static int reactorEdgeZ[REACTOR_EDGE_NUM];
static int reIdx;

void initReactor() {
  int i;
  reactorBeatCount = 0;
  reIdx = REACTOR_EDGE_NUM;
  for ( i=0 ; i<REACTOR_EDGE_NUM ; i++ ) {
    reactorEdgeZ[i] = 99999;
  }
  reactorType = 0;
  setReactorPos(reactorType, 0, 0);
}

void beatReactor() {
  reactorBeatCount = 0;
  reIdx--; if ( reIdx < 0 ) reIdx = REACTOR_EDGE_NUM-1;
  reactorEdgeZ[reIdx] = 0;
}

static void drawReactorCircle(int rr) {
  int i;
  for ( i=0 ; i<REACTOR_POS_NUM*2 ; i+=2 ) {
    drawLine(1, 
	     ((reactorPos[i].x*rr)>>8) + SCREEN_WIDTH/2, 
	     ((reactorPos[i].y*rr)>>8) + SCREEN_HEIGHT/2, 
	     ((reactorPos[i+1].x*rr)>>8) + SCREEN_WIDTH/2, 
	     ((reactorPos[i+1].y*rr)>>8) + SCREEN_HEIGHT/2);
  }
}

void drawReactor() {
  int i;
  int rr;
  for ( i=0 ; i<REACTOR_POS_NUM*2 ; i+=2 ) {
    drawLine(2, 
	     reactorPos[i].x + SCREEN_WIDTH/2, 
	     reactorPos[i].y + SCREEN_HEIGHT/2, 
	     reactorPos[i+1].x + SCREEN_WIDTH/2, 
	     reactorPos[i+1].y + SCREEN_HEIGHT/2);
  }
  rr = 256+32 - 48/(reactorBeatCount+1);
  drawReactorCircle(rr);
  for ( i=0 ; i<REACTOR_EDGE_NUM ; i++ ) {
    reactorEdgeZ[i]++;
    rr = 2048 / (7+reactorEdgeZ[i]);
    drawReactorCircle(rr);
  }

  reactorBeatCount++; 
}

int hitReactor(int x, int y) {
  int op;
  switch ( reactorType ) {
  case 0:
    op = ((REACTOR_MINOR_AXIS*REACTOR_MINOR_AXIS)>>8)*((x*x)>>8) + 
      ((REACTOR_MAJOR_AXIS*REACTOR_MAJOR_AXIS)>>8)*((y*y)>>8);
    if ( op >= ((REACTOR_MINOR_AXIS*REACTOR_MINOR_AXIS)>>8) * 
	 ((REACTOR_MAJOR_AXIS*REACTOR_MAJOR_AXIS)>>8) ) {
      return 1;
    }
    break;
  case 1:
    if ( x <= -((SCREEN_WIDTH/2)<<BASE_SHIFT) || x >= ((SCREEN_WIDTH/2)<<BASE_SHIFT) ||
	 y <= -REACTOR_MINOR_AXIS*5/6 || y >= REACTOR_MINOR_AXIS*5/6 ) {
      return 1;
    }
    break;
  case 2:
    if ( y < 0 ) {
      op = (REACTOR_MAJOR_AXIS*3/4) -
	(((REACTOR_MAJOR_AXIS/4) * 
	  sctbl[SC_TABLE_SIZE/4*(-y)/((SCREEN_HEIGHT/2)<<BASE_SHIFT)+SC_TABLE_SIZE/4])>>8);
      if ( y <= -((SCREEN_HEIGHT/2)<<BASE_SHIFT) ||
	   x <= -op || x >= op ) return 1;
    } else {
      op = (REACTOR_MAJOR_AXIS*3/4) -
	(((REACTOR_MAJOR_AXIS/4) * 
	  sctbl[SC_TABLE_SIZE/4*y/((SCREEN_HEIGHT/2)<<BASE_SHIFT)+SC_TABLE_SIZE/4])>>8);
      if ( y >= ((SCREEN_HEIGHT/2)<<BASE_SHIFT) ||
	   x <= -op || x >= op ) return 1;
    }
    break;
  }
  return 0;
}
