/*
 * $Id: genmcr.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * General-purpose macros.
 */
#ifndef GENMCR_H_
#define GENMCR_H_

#include "rand.h"

#define randN(N) ((int)(nextRand()>>5)%(N))
#define randNS(N) (((int)(nextRand()>>5))%(N<<1)-N)
#define absN(n)   ((n)<0? -(n) : (n))

#define NOT_EXIST -999999
#endif
