/*
 * $Id: bmlmng.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * States for the actions of BulletML.
 */
#ifndef BMLMNG_H_
#define BMLMNG_H_
#include "bmlprs.h"

typedef struct {
  struct actionimpl *action[CHOICE_MAX];
  int actIdx;
  BulletML *bulletml;
} BulletMLState;

typedef struct {
  int prm[PARAM_MAX];
  int idx;
} ParamValues;

#include "foe.h"

#define SPEED_BASE_SHIFT 4

struct actionimpl {
  struct foe *foe;
  Action *action;
  int repeat;
  int pc;
  int waitCnt;
  int aimSpeed, mvSpeed;
  int mvspCnt;
  int aimDrc, mvDrc;
  int isAim;
  int mvdrCnt;
  int prvFireDrc, prvFireSpeed;
  int acclCnt;
  int aimMx, aimMy, mvMx, mvMy;
  ParamValues pvs;
  struct actionimpl *parent;
  BulletMLState *state;
}; 
typedef struct actionimpl ActionImpl;

void initBulletMLManager();
int setTopActions(struct foe *fe, BulletML *bm);
void runActions(BulletMLState *st);
void rewindActions(BulletMLState *st);
void deleteActions(BulletMLState *st);
int isAllActionFinished(BulletMLState *st);
#endif
