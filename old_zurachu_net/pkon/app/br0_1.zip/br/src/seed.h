/*
 * $Id: seed.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Barrage seeds.
 */
#ifndef SEED_H_
#define SEED_H_

#include "vector.h"
#include "foe.h"

#define SEED_MAX 8

struct limiter {
  int cnt, on;
};
typedef struct limiter Limiter;

typedef struct {
  int barrageType, barrageIdx;
  int rank;
  int xReverse;
  int morphIdx[MORPH_PATTERN_MAX];
  int morphCnt;
  int morphHalf;
  int morphRank;
  int speedRank;
} Attack;

typedef struct {
  Attack attack;
  int d, md;
  Vector pos;
  int size, cnt;
  Foe *foe;
  Limiter limiter;
  int shield;
  int d1, d2;
} Seed;

extern int seedNum, seedDstCnt;

void initSeeds();
void addSeed(Attack *at, int d);
void moveSeeds();
void drawSeeds();
void clearSeeds();
#endif
