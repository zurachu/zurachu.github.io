/*
 * $Id: ship.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * Handle players ship.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include "media.h"
#include "vector.h"
#include "ship.h"
#include "reactor.h"
#include "shot.h"
#include "degutil.h"
#include "expression.h"
#include "gamemanager.h"
#include "frag.h"
#include "br.h"

Ship ship;

#define SHIP_SPEED 24

#define SHIP_INVINCIBLE_CNT_BASE 30

void initShip() {
  ship.pos.x = ship.pos.y = 0;
  ship.shotD = SC_TABLE_SIZE/2;
  ship.cnt = 0; ship.shotCnt = -1;
  ship.invCnt = 0;
  ship.rhCnt = 0;
}

#define SHOT_INTERVAL 1
#define SHOT_DEG_MV 20

static int shipMv[8][2] = {
  {0, -256}, {181, -181}, {256, 0}, {181, 181}, {0, 256}, {-181, 181}, {-256, 0}, {-181, -181},  
};

void moveShip() {
  int sd = -1;
  int pad = pcePadGet();
  int px, py;
  if ( ship.invCnt > 0 ) {
    ship.invCnt--; return;
  }
  if ( pad & PAD_RI ) {
    sd = 2;
  }
  if ( pad & PAD_LF ) {
    sd = 6;
  }
  if ( pad & PAD_DN ) {
    switch ( sd ) {
    case 2:
      sd = 3;
      break;
    case 6:
      sd = 5;
      break;
    default:
      sd = 4;
      break;
    }
  }
  if ( pad & PAD_UP ) {
    switch ( sd ) {
    case 2:
      sd = 1;
      break;
    case 6:
      sd = 7;
      break;
    default:
      sd = 0;
      break;
    }
  }
  px = ship.pos.x; py = ship.pos.y;
  if ( sd >= 0 ) {
    ship.pos.x += (SHIP_SPEED*shipMv[sd][0])>>8;
    ship.pos.y += (SHIP_SPEED*shipMv[sd][1])>>8;
  }
  if ( hitReactor(ship.pos.x, ship.pos.y) ) {
    ship.rhCnt++;
    if ( ship.rhCnt <= 1 ) {
      ship.pos.x = px; ship.pos.y = py;
    } else {
      ship.pos.x = ship.pos.x*15/16;
      ship.pos.y = ship.pos.y*15/16;
    }
  } else {
    ship.rhCnt = 0;
  }
  if ( pad & PAD_A ) {
    ship.shotD -= SHOT_DEG_MV;
  } else if ( pad & PAD_B ) {
    ship.shotD += SHOT_DEG_MV;
  }
  ship.shotD &= (SC_TABLE_SIZE-1);
  if ( ship.shotCnt < 0 && gameStatus.type == IN_GAME ) {
    addShot(&(ship.pos), ship.shotD);
    ship.shotCnt = SHOT_INTERVAL;
  }
  ship.shotCnt--;
  ship.cnt++;
  if ( ship.invCnt > 0 ) ship.invCnt--;
}

#define SHIP_DRAW_WIDTH 6
#define SHIP_DRUM_WIDTH 15
#define SHIP_DRUM_SIZE 4

void drawShip() {
  int cx, cy, d, sz;
  int i;
  int x[3], y[3];
  if ( ship.invCnt > 0 ) return;
  cx = (ship.pos.x>>BASE_SHIFT) + SCREEN_WIDTH/2;
  cy = (ship.pos.y>>BASE_SHIFT) + SCREEN_HEIGHT/2;
  d = ship.shotD;
  startDrawPolygon();
  for ( i=0 ; i<3 ; i++ ) {
    if ( i == 0 ) sz = 5;
    else          sz = 6;
    x[i] = cx + (sctbl[d]>>sz); y[i] = cy + (sctbl[d+SC_TABLE_SIZE/4]>>sz);
    d += SC_TABLE_SIZE/3; d &= (SC_TABLE_SIZE-1);
  }
  scanEdge(x[0], y[0], x[1], y[1]);
  scanEdge(x[0], y[0], x[2], y[2]);
  scanEdge(x[1], y[1], x[2], y[2]);
  drawPolygon(3, 2);
}

void destroyShip() {
  if ( ship.invCnt > 0 ) return;
  addFragsRnd(&(ship.pos), 32, 32);
  clearFoes();
  clearSeeds();
  initBulletMLManager();
  downRank();
  if ( decrementShip() ) {
    initGameover();
    ship.invCnt = 99999;
  } else {
    initShip();
    ship.invCnt = SHIP_INVINCIBLE_CNT_BASE;
  }
}

int getPlayerDeg(int x, int y) {
  return getDeg(ship.pos.x - x, ship.pos.y - y);
}
