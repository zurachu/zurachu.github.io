/*
 * $Id: frag.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Fragment data.
 */
#include "vector.h"

typedef struct {
  Vector pos, vel;
  int cnt;
} Frag;

#define FRAG_MAX 48

void initFrags();
void moveFrags();
void drawFrags();
void addFragsDeg(Vector *pos, int n, int bd, int bsp);
void addFragsVel(Vector *pos, int n, int mx, int my);
void addFragsRnd(Vector *pos, int n, int mv);
