/*
 * $Id: media.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2001 Kenta Cho. All rights reserved.
 */

/**
 * P/ECE screen/sound functions header file.
 */
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 88

#define INTERVAL 33

extern unsigned char vbuf[];
extern unsigned char PCM_R1[], PCM_R2[], PCM_R3[],
  PCM_BONUS[], PCM_BLBRK[], PCM_HIT[], PCM_SDBRK[], PCM_MISS[], PCM_EXTEND[];

void clearScreen();
void drawLine(int c, int x1, int y1, int x2, int y2);
void startDrawPolygon();
void scanEdge(int x1, int y1, int x2, int y2);
void drawPolygon(int ec, int pc);

void initSound();
void changeVolume(int ch, int v);
void playSeNow(char *snd, int ch);
void stopSeNow(int ch);
void stopSe();
void saveWaveAtt();
void loadWaveAtt();
void startBGM(char *snd);
void stopBGM();
void changeBGM(char *cg);
void playBGM();
