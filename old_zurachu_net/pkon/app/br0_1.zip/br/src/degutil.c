/*
 * $Id: degutil.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2001 Kenta Cho. All rights reserved.
 */

/**
 * Changing the cordinate into the angle.
 */
#include <math.h>

#include "degtable.h"
#include "degutil.h"

#define TAN_TABLE_SIZE 1024

/*static int tantbl[TAN_TABLE_SIZE+2];
  int sctbl[SC_TABLE_SIZE+SC_TABLE_SIZE/4];

void initDegutil() {
  int i, d = 0;
  double od = 6.28/SC_TABLE_SIZE;
  for ( i=0 ; i<TAN_TABLE_SIZE ; i++ ) {
    while ( (int)(sin(d*od)/cos(d*od)*TAN_TABLE_SIZE)<i ) d++;
    tantbl[i] = d;
  }
  tantbl[TAN_TABLE_SIZE] = tantbl[TAN_TABLE_SIZE+1] = 128;

  for ( i=0 ; i<SC_TABLE_SIZE+SC_TABLE_SIZE/4 ; i++ ) {
    sctbl[i] = (int)(sin(i*(6.28/SC_TABLE_SIZE))*256);
  }

  for ( i=0 ; i<TAN_TABLE_SIZE+2 ; i++ ) {
    if ( (i&15) == 0 ) printf("\n");
    printf("%d,", tantbl[i]);
  }
  for ( i=0 ; i<SC_TABLE_SIZE+SC_TABLE_SIZE/4 ; i++ ) {
    if ( (i&15) == 0 ) printf("\n");
    printf("%d,", sctbl[i]);
  }
  }*/

int getDeg(int x, int y) {
  int tx, ty;
  int f, od, tn;

  if ( x==0 && y==0 ) {
    return(0);
  }

  if ( x < 0 ) {
    tx = -x;
    if ( y < 0 ) {
      ty = -y;
      if ( tx > ty ) {
	f = 1;
	od = SC_TABLE_SIZE*3/4; tn = (long)ty*TAN_TABLE_SIZE/tx;
      } else {
	f = -1;
	od = SC_TABLE_SIZE; tn = (long)tx*TAN_TABLE_SIZE/ty;
      }
    } else {
      ty = y;
      if ( tx > ty ) {
	f = -1;
	od = SC_TABLE_SIZE*3/4; tn = (long)ty*TAN_TABLE_SIZE/tx;
      } else {
	f=1;
	od = SC_TABLE_SIZE/2; tn = (long)tx*TAN_TABLE_SIZE/ty;
      }
    }
  } else {
    tx = x;
    if ( y < 0 ) {
      ty = -y;
      if ( tx > ty ) {
	f = -1;
	od = SC_TABLE_SIZE/4; tn = (long)ty*TAN_TABLE_SIZE/tx;
      } else {
	f = 1;
	od = 0; tn = (long)tx*TAN_TABLE_SIZE/ty;
      }
    } else {
      ty = y;
      if ( tx > ty ) {
	f = 1;
	od = SC_TABLE_SIZE/4; tn = (long)ty*TAN_TABLE_SIZE/tx;
      } else {
	f = -1;
	od = SC_TABLE_SIZE/2; tn = (long)tx*TAN_TABLE_SIZE/ty;
      }
    }
  }
  return((od+tantbl[tn]*f)&(SC_TABLE_SIZE-1));
}

int getDistance(int x, int y) {
  if ( x < 0 ) x = -x;
  if ( y < 0 ) y = -y;
  if ( x > y ) {
    return x + (y>>1);
  } else {
    return y + (x>>1);
  }
}
