/*
 * $Id: letterrender.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * Letter render header file.
 */
void drawLetter(int idx, int r, int d, int ltSize);
void drawString(char *str, int lr, int ld, int ltSize);
void drawNum(int num, int lr, int ld, int ltSize);
