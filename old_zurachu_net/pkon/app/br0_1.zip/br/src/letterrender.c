/*
 * $Id: letterrender.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Letter render.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include "letterrender.h"
#include "letterdata.h"
#include "media.h"
#include "degutil.h"
#include "reactor.h"

void drawLetter(int idx, int r, int d, int ltSize) {
  int i;
  int x, y, length, tx;
  int ox, oy;
  int deg, ldeg;
  int lx, ly, ldi, ldo;
  d += 512; d &= SC_TABLE_SIZE-1;
  ldi = d>>6; ldi <<= 1;
  ldo = (d&63);
  lx = ((((reactorPos[ldi].x*(64-ldo) + reactorPos[ldi+1].x*ldo)>>6)*r)>>8) + SCREEN_WIDTH/2;
  ly = ((((reactorPos[ldi].y*(64-ldo) + reactorPos[ldi+1].y*ldo)>>6)*r)>>8) + SCREEN_HEIGHT/2;
  for ( i=0 ; ; i++ ) {
    deg = (int)spData[idx][i][4];
    length = spData[idx][i][3]*ltSize;
    if ( deg > 99990 ) break;
    deg = deg*SC_TABLE_SIZE/360;
    switch ( reactorType ) {
    case 0:
      deg += d; 
      deg &= SC_TABLE_SIZE-1;
      x = -spData[idx][i][0]*ltSize;
      y =  spData[idx][i][1]*ltSize;
      ldeg = 1023-d;
      tx = (x*sctbl[ldeg+SC_TABLE_SIZE/4] - y*sctbl[ldeg])>>8;
      y  = (x*sctbl[ldeg] + y*sctbl[ldeg+SC_TABLE_SIZE/4])>>8;
      x = tx + lx;
      y += ly;
      ldeg = 1023-deg;
      ox = (sctbl[ldeg+SC_TABLE_SIZE/4]*length)>>7;
      oy = (sctbl[ldeg]                *length)>>7;
      break;
    case 1:
      x =  spData[idx][i][0]*ltSize;
      y = -spData[idx][i][1]*ltSize;
      if ( d < 256 || d >= 768 ) {
	x = -x; y = -y;
      }
      x += lx; y += ly;
      ldeg = deg;
      ox = (sctbl[ldeg+SC_TABLE_SIZE/4]*length)>>7;
      oy = (sctbl[ldeg]                *length)>>7;
      break;
    case 2:
      x = -spData[idx][i][1]*ltSize;
      y = -spData[idx][i][0]*ltSize;
      if ( d < 512 ) {
	x = -x; y = -y;
      }
      x += lx; y += ly;
      ldeg = deg + 256;
      ldeg &= SC_TABLE_SIZE-1;
      ox = (sctbl[ldeg+SC_TABLE_SIZE/4]*length)>>7;
      oy = (sctbl[ldeg]                *length)>>7;
      break;
    default:
      x = y = ox = oy = 0;
      break;
    }
    drawLine(3, x-ox, y-oy, x+ox, y+oy);
  }
}

static int md, r;

static void setReactorAdjust(int ltSize, int lr) {
  switch ( reactorType ) {
    case 0:
      md = ltSize*6*256/lr; 
      r = lr;
      break;
    case 1:
      md = ltSize*7*256/lr;
      r = lr*8/7;
      break;
    case 2:
      md = ltSize*8*256/lr;
      r = lr*5/4;
      break;
    default:
      md = 0; r = lr;
      break;
  }
}		       

void drawString(char *str, int lr, int ld, int ltSize) {
  int d = ld;
  int i, c, idx;
  setReactorAdjust(ltSize, lr);
  for ( i=0 ; ; i++ ) {
    if ( str[i] == '\0' ) break;
    c = str[i];
    if ( c != ' ' ) {
      if ( c >= '0' && c <='9' ) {
	idx = c-'0';
      } else if ( c >= 'A' && c <= 'Z' ) {
	idx = c-'A'+10;
      } else if ( c >= 'a' && c <= 'z' ) {
	idx = c-'a'+10;
      } else if ( c == '.' ) {
	idx = 36;
      } else if ( c == '-' ) {
	idx = 38;
      } else if ( c == '+' ) {
	idx = 39;
      } else {
	idx = 37;
      }
      d &= SC_TABLE_SIZE-1;
      drawLetter(idx, r, d, ltSize);
    }
    d -= md;
  }
}

void drawNum(int num, int lr, int ld, int ltSize) {
  int n = num, i, d = ld;
  setReactorAdjust(ltSize, lr);
  for ( i=0 ; ; i++ ) {
    if ( i > 0 && n <= 0 ) return;
    d &= SC_TABLE_SIZE-1;
    drawLetter(n%10, r, d, ltSize);
    n /= 10;
    d += md;
  }
}
