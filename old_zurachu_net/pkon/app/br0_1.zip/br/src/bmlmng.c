/*
 * $Id: bmlmng.c,v 1.3 2003/05/25 13:44:29 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * BulletML manager.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include <string.h>

#include "bmlmng.h"
#include "bmlprs.h"
#include "expression.h"
#include "genmcr.h"
#include "degutil.h"
#include "ship.h"

#define ACTIONIMPL_MAX 128
static ActionImpl actionImpl[ACTIONIMPL_MAX];
static int aiIdx;

void initBulletMLManager() {
  int i;
  for ( i=0 ; i<ACTIONIMPL_MAX ; i++ ) {
    actionImpl[i].repeat = NOT_EXIST;
  }
  aiIdx = ACTIONIMPL_MAX;
}

static ActionImpl* getActionImplInstance() {
  int i;
  for ( i=0 ; i<ACTIONIMPL_MAX ; i++ ) {
    aiIdx--; if ( aiIdx < 0 ) aiIdx = ACTIONIMPL_MAX-1;
    if ( actionImpl[aiIdx].repeat == NOT_EXIST ) return &(actionImpl[aiIdx]);
  }
  return NULL;
}

static Action* getLabeledAction(BulletML *bm, char *label) {
  int i;
  for ( i=0 ; i<bm->actIdx ; i++ ) {
    if ( bm->action[i].label != NULL && strcmp(label, bm->action[i].label) == 0 ) {
      return &(bm->action[i]);
    }
  }
  return NULL;
}

static Bullet* getLabeledBullet(BulletML *bm, char *label) {
  int i;
  for ( i=0 ; i<bm->bltIdx ; i++ ) {
    if ( bm->bullet[i].label != NULL && strcmp(label, bm->bullet[i].label) == 0 ) {
      return &(bm->bullet[i]);
    }
  }
  return NULL;
}

static Fire* getLabeledFire(BulletML *bm, char *label) {
  int i;
  for ( i=0 ; i<bm->frIdx ; i++ ) {
    if ( bm->fire[i].label != NULL && strcmp(label, bm->fire[i].label) == 0 ) {
      return &(bm->fire[i]);
    }
  }
  return NULL;
}

static ParamValues tpvs;

static ParamValues* getParamValues(Params *prms, ParamValues *pvs, int rank) {
  int i;
  if ( prms->idx <= 0 ) return NULL;
  for ( i=0 ; i<prms->idx ; i++ ) {
    tpvs.prm[i] = evalExpression(&(prms->prm[i]), pvs->prm, rank);
  }
  tpvs.idx = prms->idx;
  return &tpvs;
}

static void changeAction(BulletMLState *st, ActionImpl *pai, ActionImpl *nai) {
  int i;
  for ( i=0 ; i<st->actIdx ; i++ ) {
    if ( st->action[i] == pai ) {
      st->action[i] = nai;
      return;
    }
  }
}

void initAction(ActionImpl *ai) {
  ai->repeat = 1; ai->pc = -1;
  ai->waitCnt = ai->mvspCnt = ai->mvdrCnt = ai->acclCnt = 0;
  ai->mvMx = ai->mvMy = ai->aimMx = ai->aimMy = 0;
  ai->prvFireDrc = 0; ai->prvFireSpeed = 1;
  ai->parent = NULL;
  ai->pvs.idx = 0;
}

static void setAction(ActionImpl *ai, Action *act, Foe *foe, BulletMLState *st) {
  ai->action = act; ai->foe = foe; ai->state = st;
  initAction(ai);
}

int setTopActions(Foe *fe, BulletML *bm) {
  int i, j;
  fe->state.bulletml = bm;
  for ( i=0 ; i<bm->topActIdx ; i++ ) {
    fe->state.action[i] = getActionImplInstance();
    if ( fe->state.action[i] == NULL ) {
      for ( j=0 ; j<i ; j++ ) {
	fe->state.action[j]->repeat = NOT_EXIST;
      }
      fe->state.actIdx = 0;
      return 0;
    }
    setAction(fe->state.action[i], bm->topAction[i], fe, &(fe->state));
  }
  fe->state.actIdx = bm->topActIdx;
  return 1;
}

static void setActionStatus(ActionImpl *ai,
			    int mvdrCnt, int mvDrc, int isAim, int mvspCnt, 
			    int mvSpeed, int acclCnt, int mvMx, int mvMy, 
			    int prvFireDrc, int prvFireSpeed) {
  ai->mvdrCnt = mvdrCnt; ai->mvDrc = mvDrc; ai->isAim = isAim; ai->mvspCnt = mvspCnt;
  ai->mvSpeed = mvSpeed; ai->acclCnt = acclCnt; ai->mvMx = mvMx; ai->mvMy = mvMy;
  ai->prvFireDrc = prvFireDrc; ai->prvFireSpeed = prvFireSpeed;
}

static int getAimDeg(Foe *fe) {
  return getPlayerDeg(fe->pos.x, fe->pos.y);
}

static void runAction(ActionImpl *ai) {
  int loopf = 1;
  IActionChoice *ac;
  ActionImpl *newAction;
  Fire *fire;
  Bullet *blt;
  ParamValues *pvs, *pvsa, *pvsb;
  BulletMLState st;
  Direction *d;
  Speed *s;
  int dv;
  int sv;
  int i, j;
  Accel *al;
  Horizontal *hrz;
  Vertical *vtc;

  if ( ai->mvspCnt > 0 ) {
    ai->mvspCnt -= 2;
    ai->foe->spd += (ai->mvSpeed<<1);
  }
  if ( ai->mvdrCnt > 0 ) {
    ai->mvdrCnt -= 2;
    ai->foe->d += (ai->mvDrc<<1);
    ai->foe->d &= (SC_TABLE_SIZE*BASE_MAG-1);
  }
  if ( ai->acclCnt > 0 ) {
    ai->acclCnt -= 2;
    ai->foe->vel.x += (ai->mvMx<<1);
    ai->foe->vel.y += (ai->mvMy<<1);
  }
  if ( ai->repeat == NOT_EXIST ) return;

  if ( ai->waitCnt > 0 ) {
    ai->waitCnt -= 2;
    return;
  }

  while ( loopf ) {
    ai->pc++;
    if ( ai->pc >= ai->action->cn ) {
      ai->repeat--;
      if ( ai->repeat <= 0 ) {
        ai->repeat = NOT_EXIST;
        if ( ai->parent != NULL ) {
          setActionStatus(ai->parent,
			  ai->mvdrCnt, ai->mvDrc, ai->isAim, ai->mvspCnt, 
			  ai->mvSpeed, ai->acclCnt, ai->mvMx, ai->mvMy, 
			  ai->prvFireDrc, ai->prvFireSpeed);
	  changeAction(ai->state, ai, ai->parent);
        }
        break;
      } else {
        ai->pc = 0;
      }
    }

    ac = &(ai->action->c[ai->pc]);
    switch ( ac->n ) {
    case REPEAT:
      /* Repeat action. */
      newAction = getActionImplInstance();
      if ( newAction != NULL ) {
	ParamValues *pvs;
        Repeat *rp = ac->u.rp;
	Action *act;
        int rpNum = evalExpression(&(rp->times), ai->pvs.prm, ai->foe->rank)>>BASE_SHIFT;
        if ( rpNum <= 0 ) return;
	if ( rp->a[0].n == ACTION ) {
	  act = rp->a[0].u.a;
	} else {
	  act = getLabeledAction(ai->state->bulletml, rp->a[0].u.ar->label);
	}
	if ( act == NULL ) break;
        setAction(newAction, act, ai->foe, ai->state);
	if ( rp->a[0].n == ACTION_REF ) {
	  pvs = getParamValues(&(rp->a[0].u.ar->prms), &(ai->pvs), ai->foe->rank);
	} else {
	  pvs = NULL;
	}
        if ( pvs == NULL ) {
	  newAction->pvs = ai->pvs;
        } else {
	  newAction->pvs = *pvs;
        }
	newAction->repeat = rpNum;
	newAction->parent = ai;
	setActionStatus(newAction,
			ai->mvdrCnt, ai->mvDrc, ai->isAim, ai->mvspCnt, 
			ai->mvSpeed, ai->acclCnt, ai->mvMx, ai->mvMy, 
			ai->prvFireDrc, ai->prvFireSpeed);
	changeAction(ai->state, ai, newAction);
        runAction(newAction);
	loopf = 0;
      }
      break;
    case ACTION:
    case ACTION_REF:
      /* Action. */
      newAction = getActionImplInstance();
      if ( newAction != NULL ) {
	Action *act;
	ParamValues *pvs;
	if ( ac->n == ACTION ) {
	  act = ac->u.a;
	} else {
	  act = getLabeledAction(ai->state->bulletml, ac->u.ar->label);
	}
	if ( act == NULL ) break;
	setAction(newAction, act, ai->foe, ai->state);
	if ( ac->n == ACTION_REF ) {
	  pvs = getParamValues(&(ac->u.ar->prms), &(ai->pvs), ai->foe->rank);
	} else {
	  pvs = NULL;
	}
        if ( pvs == NULL ) {
          newAction->pvs = ai->pvs;
        } else {
	  newAction->pvs = *pvs;
        }
        newAction->repeat = 1;
        newAction->parent = ai;
	setActionStatus(newAction,
			ai->mvdrCnt, ai->mvDrc, ai->isAim, ai->mvspCnt, 
			ai->mvSpeed, ai->acclCnt, ai->mvMx, ai->mvMy, 
			ai->prvFireDrc, ai->prvFireSpeed);
	changeAction(ai->state, ai, newAction);
        runAction(newAction);
	loopf = 0;
      }
      break;
    case FIRE:
    case FIRE_REF:
      /* Fire action. */
      if ( ac->n == FIRE ) {
	fire = ac->u.f;
	pvs = NULL;
      } else {
	fire = getLabeledFire(ai->state->bulletml, ac->u.fr->label);
	pvs = getParamValues(&(ac->u.fr->prms), &(ai->pvs), ai->foe->rank);
      }
      if ( fire == NULL ) break;
      if ( pvs == NULL ) pvs = &(ai->pvs);
      if ( fire->b.n == BULLET ) {
	blt = fire->b.u.b;
	pvsb = NULL;
      } else {
	blt = getLabeledBullet(ai->state->bulletml, fire->b.u.br->label);
	pvsb = getParamValues(&(fire->b.u.br->prms), pvs, ai->foe->rank);
      }
      if ( blt == NULL ) break;
      if ( pvsb == NULL ) pvsb = pvs;
      st.actIdx = blt->cn;
      for ( i=0 ; i<blt->cn ; i++ ) {
	Action *act;
	st.action[i] = getActionImplInstance();
	if ( st.action[i] == NULL ) {
	  for ( j=0 ; j<i ; j++ ) {
	    st.action[j]->repeat = NOT_EXIST;
	  }
	  st.actIdx = -1;
	  break;
	}
	if ( blt->c[i].n == ACTION ) {
	  act = blt->c[i].u.a;
	} else {
	  act = getLabeledAction(ai->state->bulletml, blt->c[i].u.ar->label);
	}
	if ( act == NULL ) break;
	setAction(st.action[i], act, ai->foe, ai->state);
	if ( blt->c[i].n == ACTION_REF ) {
	  pvsa = getParamValues(&(blt->c[i].u.ar->prms), pvsb, ai->foe->rank);
	} else {
	  pvsa = NULL;
	}
	if ( pvsa == NULL ) {
	  st.action[i]->pvs = *pvsb;
	} else {
	  st.action[i]->pvs = *pvsa;
	}
      }
      if ( st.actIdx == -1 ) break;
      st.bulletml = ai->state->bulletml;
      d = &(blt->d);
      if ( d->num.idx <= 0 ) d = &(fire->d);
      if ( d->num.idx <= 0 ) {
	dv = getAimDeg(ai->foe)<<BASE_SHIFT;
      } else {
	dv = (long)evalExpression(&(d->num), pvsb->prm, ai->foe->rank)*SC_TABLE_SIZE/360;
	switch( d->type ) {
	case AIM:
	  dv += getAimDeg(ai->foe)<<BASE_SHIFT;
	  break;
	case RELATIVE:
	  dv += ai->foe->d;
	  break;
	case SEQUENCE:
	  dv += ai->prvFireDrc;
	  break;
	}
      }
      dv &= (SC_TABLE_SIZE*BASE_MAG-1);
      ai->prvFireDrc = dv;
      s = &(blt->s);
      if ( s->num.idx <= 0 ) s = &(fire->s);
      if ( s->num.idx <= 0 ) {
	sv = BASE_MAG;
      } else {
	sv = evalExpression(&(s->num), pvsb->prm, ai->foe->rank);
      }
      switch ( s->type ) {
      case RELATIVE:
	sv <<= SPEED_BASE_SHIFT;
	sv += ai->foe->spd;
	break;
      case SEQUENCE:
	sv <<= SPEED_BASE_SHIFT;
	sv += ai->prvFireSpeed;
	break;
      default:
	sv <<= SPEED_BASE_SHIFT;
	break;
      }
      ai->prvFireSpeed = sv;
      if ( st.actIdx > 0 ) {
	addFoeActiveBullet(ai->foe, dv, sv, &st);
      } else {
	addFoeNormalBullet(ai->foe, dv, sv);
      }
      break;
    case CHANGE_SPEED:
      /* Change speed action. */
      s = &(ac->u.cs->s);
      ai->mvspCnt = evalExpression(&(ac->u.cs->term), ai->pvs.prm, ai->foe->rank)>>BASE_SHIFT;
      switch ( s->type ) {
      case SEQUENCE:
	ai->mvSpeed = evalExpression(&(s->num), ai->pvs.prm, ai->foe->rank)<<SPEED_BASE_SHIFT;
	break;
      case ABSOLUTE:
      case RELATIVE:
	ai->aimSpeed = evalExpression(&(s->num), ai->pvs.prm, ai->foe->rank);
	ai->aimSpeed <<= SPEED_BASE_SHIFT;
	if ( s->type == RELATIVE ) ai->aimSpeed += ai->foe->spd;
	ai->mvSpeed = (ai->aimSpeed - ai->foe->spd) / ai->mvspCnt;
	break;
      }
      break;
    case CHANGE_DIRECTION:
      /* Change direction action. */
      d = &(ac->u.cd->d);
      ai->mvdrCnt = evalExpression(&(ac->u.cd->term), ai->pvs.prm, ai->foe->rank)>>BASE_SHIFT;
      switch ( d->type ) {
      case SEQUENCE:
	ai->isAim = 0;
	ai->mvDrc = ((long)evalExpression(&(d->num), ai->pvs.prm, ai->foe->rank)*SC_TABLE_SIZE/360)
	  & (SC_TABLE_SIZE*BASE_MAG-1);
	break;
      case AIM:
      case ABSOLUTE:
      case RELATIVE:
	dv = (long)evalExpression(&(d->num), ai->pvs.prm, ai->foe->rank)*SC_TABLE_SIZE/360;
	switch ( d->type ) {
	case RELATIVE:
	  dv += ai->foe->d;
	case ABSOLUTE:
	  ai->isAim = 0;
	  ai->aimDrc = dv & (SC_TABLE_SIZE*BASE_MAG-1); 
	  ai->mvDrc = (ai->aimDrc - ai->foe->d)&(SC_TABLE_SIZE*BASE_MAG-1);
	  break;
	case AIM:
	  ai->isAim = 1;
	  ai->aimDrc = dv & (SC_TABLE_SIZE*BASE_MAG-1); 
	  ai->mvDrc = (ai->aimDrc+(getAimDeg(ai->foe)<<BASE_SHIFT) - ai->foe->d) & 
	    (SC_TABLE_SIZE*BASE_MAG-1);
	  break;
	}
        if ( ai->mvDrc >  SC_TABLE_SIZE*BASE_MAG/2 ) ai->mvDrc -= SC_TABLE_SIZE*BASE_MAG;
        if ( ai->mvDrc < -SC_TABLE_SIZE*BASE_MAG/2 ) ai->mvDrc += SC_TABLE_SIZE*BASE_MAG;
        ai->mvDrc /= ai->mvdrCnt;
	break;
      }
      break;
    case ACCEL:
      /* Accel bullet. */
      al = ac->u.ac;
      ai->acclCnt = evalExpression(&(al->term), ai->pvs.prm, ai->foe->rank)>>BASE_SHIFT;
      hrz = &(al->h);
      if ( hrz->num.idx > 0 ) {
	switch ( hrz->type ) {
	case SEQUENCE:
	  ai->mvMx = evalExpression(&(hrz->num), ai->pvs.prm, ai->foe->rank)<<SPEED_BASE_SHIFT;
	  break;
	case ABSOLUTE:
	case RELATIVE:
	  ai->aimMx = evalExpression(&(hrz->num), ai->pvs.prm, ai->foe->rank);
	  if ( hrz->type == RELATIVE ) ai->aimMx += ai->foe->mv.x;
	  ai->aimMx <<= SPEED_BASE_SHIFT;
	  ai->mvMx = (ai->aimMx - ai->foe->mv.x) / ai->acclCnt;
	  break;
	}
      }
      vtc = &(al->v);
      if ( vtc->num.idx > 0 ) {
	switch ( vtc->type ) {
	case SEQUENCE:
	  ai->mvMy = evalExpression(&(vtc->num), ai->pvs.prm, ai->foe->rank)<<SPEED_BASE_SHIFT;
	  break;
	case ABSOLUTE:
	case RELATIVE:
	  ai->aimMy = evalExpression(&(vtc->num), ai->pvs.prm, ai->foe->rank);
	  if ( vtc->type == RELATIVE ) ai->aimMy += ai->foe->mv.y;
	  ai->aimMy <<= SPEED_BASE_SHIFT;
	  ai->mvMy = (ai->aimMy - ai->foe->mv.y) / ai->acclCnt;
	  break;
	}
      }
      break;
    case WAIT:
      /* Wait action. */
      ai->waitCnt = evalExpression(&(ac->u.w->num), ai->pvs.prm, ai->foe->rank)>>BASE_SHIFT;
      loopf = 0;
      break;
    case VANISH:
      /* Vanish a bullet. */
      removeFoe(ai->foe);
      loopf = 0;
      break;
    }
  }
}

void runActions(BulletMLState *st) {
  int i;
  for ( i=0 ; i<st->actIdx ; i++ ) {
    runAction(st->action[i]);
  }
}

void rewindActions(BulletMLState *st) {
  int i;
  for ( i=0 ; i<st->actIdx ; i++ ) {
    initAction(st->action[i]);
  }
}

void deleteActions(BulletMLState *st) {
  int i;
  ActionImpl *ai;
  for ( i=0 ; i<st->actIdx ; i++ ) {
    ai = st->action[i];
    for ( ; ; ) {
      ai->repeat = NOT_EXIST;
      if ( ai->parent == NULL ) break;
      ai = ai->parent;
    }
  }
}

int isAllActionFinished(BulletMLState *st) {
  int i;
  for ( i=0 ; i<st->actIdx ; i++ ) {
    if ( st->action[i]->repeat != NOT_EXIST ) return 0;
  }
  return 1;
}
