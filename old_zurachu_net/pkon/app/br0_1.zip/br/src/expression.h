/*
 * $Id: expression.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Expressions represented by RPN.
 */
#ifndef EXPRESSION_H_
#define EXPRESSION_H_

#define STACK_VARIABLE 11
#define STACK_RANK -2
#define STACK_RAND -1
#define STACK_NUM 0
#define PLUS 1
#define MINUS 2
#define MULTIPLE 3
#define DIVISION 4
#define MODULO 5

#define BASE_MAG 16
#define BASE_SHIFT 4

#define EXPRESSION_MAX 12

typedef struct {
  int num[EXPRESSION_MAX];
  int opr[EXPRESSION_MAX];
  int idx;
} Expression;

int evalExpression(Expression *ep, int *prms, int rank);
#endif
