/*
 * $Id: ship.h,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * Player data.
 */
#ifndef DEF_SHIP
#define DEF_SHIP

#include "vector.h"

typedef struct {
  Vector pos;
  int shotD;
  int cnt, shotCnt;
  int invCnt;
  int rhCnt;
} Ship;

extern Ship ship;

void initShip();
void moveShip();
void drawShip();
void destroyShip();
int getPlayerDeg(int x, int y);
#endif
