/*
 * $Id: gamemanager.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Game manager.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#else
#include "piece2sdl.h"
#endif

#include <math.h>
#include "genmcr.h"
#include "gamemanager.h"
#include "seed.h"
#include "expression.h"
#include "vector.h"
#include "degutil.h"
#include "brgmng.h"
#include "letterrender.h"
#include "media.h"
#include "foe.h"
#include "reactor.h"
#include "br.h"

GameStatus gameStatus;
static Attack at;
int limiterBulletsNum;
static int seedAddCnt;

static void setAttackIndex(Attack *at) {
  int i;
  at->xReverse = randN(2)*2-1;
  at->barrageIdx = randN(normalBarragePatternNum);
  for ( i=0 ; i<MORPH_PATTERN_MAX ; i++ ) {
    at->morphIdx[i] = randN(morphBarragePatternNum);
  }
  if ( randN(4) == 0 ) at->morphHalf = 1;
  else                 at->morphHalf = 0;
}

static void setAttackRank(Attack *at, float rank) {
  double atRank, atSpeedRank, atMorphRank;
  if ( rank <= 0.3 ) {
    atRank = rank;
    at->morphCnt = atMorphRank = 0;
    atSpeedRank = 1;
  } else {
    atRank = rank*(90+randN(38))/256.0;
    if ( atRank > 0.8 ) {
      atRank = 0.2*(randN(8)+1)/8.0 + 0.8;
    }
    rank /= (atRank+2);
    atSpeedRank = sqrt(rank)*(randN(100)+100)/256;
    if ( atSpeedRank < 0.6 ) atSpeedRank = 0.6;
    atMorphRank = rank / atSpeedRank;
    at->morphCnt = 0;
    while ( atMorphRank > 1 ) {
      at->morphCnt++;
      atMorphRank /= 3;
    }
  }
  at->rank = atRank*BASE_MAG;
  at->morphRank = atMorphRank*BASE_MAG;
  atSpeedRank *= 0.8;
  at->speedRank = atSpeedRank*BASE_MAG;
}

static int pscr;
static int brt, rcCnt;

void initGamemanager() {
  gameStatus.score = 0;
  loadHiScore();
}

static char leftStr[6] = "left 0";

static void setLeftStr() {
  leftStr[5] = '0' + gameStatus.left;
}

void startGame() {
  gameStatus.cnt = 0;
  gameStatus.type = IN_GAME;
  gameStatus.score = 0;
  gameStatus.left = 2;
  setLeftStr();
  seedAddCnt = 0;
  seedDstCnt = 0;

  gameStatus.rank = 0.1f;
  setAttackIndex(&at);
  setAttackRank(&at, gameStatus.rank);
  gameStatus.limiterBulletsNum = 1;
  gameStatus.seedMax = 4;
  gameStatus.seedAppItv = 50;
  pscr = 0;
  rcCnt = 0;
}

void startGameover() {
  brt = reactorType;
  reactorType = 0;
  rcCnt = 256;
  if ( gameStatus.score > gameStatus.hiScore ) {
    gameStatus.hiScore = gameStatus.score;
  }
}

static void extendShip() {
  playSeNow(PCM_EXTEND, 3);
  if ( gameStatus.left < 9 ) gameStatus.left++;
  setLeftStr();
}

int decrementShip() {
  playSeNow(PCM_MISS, 3);
  gameStatus.left--;
  if ( gameStatus.left < 0 ) return 1;
  setLeftStr();
  return 0;
}

static void nextAttack() {
  setAttackIndex(&at);
  setAttackRank(&at, gameStatus.rank);
  seedDstCnt = 0;
  gameStatus.limiterBulletsNum++;
}

void addScore() {
  int sco, scr;
  gameStatus.score++;
  sco = gameStatus.score%1000;
  scr = gameStatus.score/1000;
  gameStatus.seedMax = 3 + sco/180 + scr;
  if ( gameStatus.seedMax > SEED_MAX ) gameStatus.seedMax = SEED_MAX;
  if ( scr > pscr ) {
    pscr = scr;
    if ( scr%3 == 0 ) extendShip();
    else playSeNow(PCM_SDBRK, 2);
    clearFoes();
    clearSeeds();
    initBulletMLManager();
    nextAttack();
    switch ( scr%3 ) {
    case 0:
      changeBGM(PCM_R1);
      break;
    case 1:
      changeBGM(PCM_R2);
      break;
    case 2:
      changeBGM(PCM_R3);
      break;
    }
    brt = reactorType;
    reactorType = scr%3;
    rcCnt = 256;
  }
  gameStatus.seedAppItv = (100 - sco/12)*5/(5+scr);
}

void moveGamemanager() {
  int pad = pcePadGet();
  switch ( gameStatus.type ) {
  case TITLE:
    if ( pad & TRG_C ) {
      initInGame();
      return;
    }
    break;
  case IN_GAME:
    if ( seedNum < gameStatus.seedMax && ship.invCnt <= 0 ) {
      seedAddCnt--;
      if ( seedAddCnt < 0 || seedNum == 0 ) {
	if ( seedDstCnt >= 8 ) {
	  nextAttack();
	}
	addSeed(&at, randN(SC_TABLE_SIZE));
	seedAddCnt = (gameStatus.seedAppItv*(256+randNS(64)))>>8;
      }
    }
    gameStatus.rank += 0.0032;
    if ( rcCnt > 0 ) {
      rcCnt -= 4;
      setReactorPos(reactorType, brt, rcCnt);
    }
    break;
  case GAMEOVER:
    if ( rcCnt > 0 ) {
      rcCnt -= 4;
      setReactorPos(reactorType, brt, rcCnt);
    }
    if ( (pad & TRG_C) || gameStatus.cnt > 320 ) {
      initTitle();
      return;
    }
    break;
  }
  gameStatus.cnt++;
}

void downRank() {
  gameStatus.rank *= 0.75f;
  setAttackIndex(&at);
  setAttackRank(&at, gameStatus.rank);
}

void drawGamemanager() {
  int ls;
  switch ( gameStatus.type ) {
  case TITLE:
    drawString("BARRAGE REACTOR", 200, gameStatus.cnt, 6);
    break;
  case IN_GAME:
    switch ( reactorType ) {
    case 0:
    case 1:
      drawString(leftStr, 280, 700, 4);
      break;
    case 2:
      drawString(leftStr, 280, 750, 4);
      break;
    }
    break;
  case GAMEOVER:
    if ( gameStatus.cnt < 32 ) {
      ls = gameStatus.cnt>>2;
    } else {
      ls = 8;
    }
    drawString("GAME OVER", 172, gameStatus.cnt*2, ls);
    break;
  }
  drawNum(gameStatus.score, 280, 90, 4);
  if ( gameStatus.type != IN_GAME ) {
    drawNum(gameStatus.hiScore, 290, 350, 4);
  }
}

#define HISCORE_FILE "br.cfg"
#define DEFAULT_HI_SCORE 1000

void loadHiScore() {
#ifndef _PIECE2SDL
  FILEACC pfa;
  if ( pceFileOpen(&pfa, HISCORE_FILE, FOMD_RD) == 0 ) {
    pceFileReadSct(&pfa, &(gameStatus.hiScore), 0, sizeof(int));
    pceFileClose(&pfa);
  } else {
    pceFileCreate(HISCORE_FILE, sizeof(int));
    gameStatus.hiScore = DEFAULT_HI_SCORE;
  }
#else
  gameStatus.hiScore = DEFAULT_HI_SCORE;
#endif
}

void saveHiScore() {
#ifndef _PIECE2SDL
  FILEACC pfa;
  if ( pceFileOpen(&pfa, HISCORE_FILE, FOMD_WR) == 0 ) {
    pceFileWriteSct(&pfa, &(gameStatus.hiScore), 0, sizeof(int));
    pceFileClose(&pfa);
  }
#endif
}
