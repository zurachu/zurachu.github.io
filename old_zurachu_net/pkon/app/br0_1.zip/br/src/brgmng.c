/*
 * $Id: brgmng.c,v 1.1.1.1 2003/05/25 11:50:09 kenta Exp $
 *
 * Copyright 2003 Kenta Cho. All rights reserved.
 */

/**
 * Handle barrages.
 */
#ifndef _PIECE2SDL
#include <piece.h>
#define malloc(P) pceHeapAlloc(P)
#else
#include <stdlib.h>
#endif

#include "brgmng.h"

#include "bmldata.h"

BulletML *normalBarragePattern, *morphBarragePattern;
int normalBarragePatternNum, morphBarragePatternNum;

void initBarragemanager() {
  normalBarragePatternNum = 3;
  normalBarragePattern = (BulletML*)malloc(sizeof(BulletML)*normalBarragePatternNum);
  loadBulletML(&normalBarragePattern[0], bml_aim);
  loadBulletML(&normalBarragePattern[1], bml_vertical);
  loadBulletML(&normalBarragePattern[2], bml_scatter);
  morphBarragePatternNum = 7;
  morphBarragePattern = (BulletML*)malloc(sizeof(BulletML)*morphBarragePatternNum);
  loadBulletML(&morphBarragePattern[0], bml_allround);
  loadBulletML(&morphBarragePattern[1], bml_changeaim);
  loadBulletML(&morphBarragePattern[2], bml_growexpand);
  loadBulletML(&morphBarragePattern[3], bml_nway);
  loadBulletML(&morphBarragePattern[4], bml_traceshot);
  loadBulletML(&morphBarragePattern[5], bml_rollslow);
  loadBulletML(&morphBarragePattern[6], bml_extendfast);
}
