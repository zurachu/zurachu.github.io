#include <piece.h>
#include <string.h>
#include "pshell.h"

// �L���v�V�����̎擾
static void getCaption(char *caption, const char *fileName){
  FILEACC facc;
  pffsFileHEADER *fileHeader;
  char fileBuffer[SECTOR_SIZE];
  int s;

  pceFileOpen(&facc, fileName, FOMD_RD);
  s = pceFileReadSct(&facc, fileBuffer, 0, SECTOR_SIZE);
  pceFileClose(&facc);

  fileHeader = (pffsFileHEADER *)fileBuffer;

  if(s < sizeof(pffsFileHEADER)){
    strcpy(caption, "");
  }
  else{
    strncpy(caption, fileBuffer + fileHeader->ofs_name, CAPTION_MAX);
  }
}

////////////////////////////////////////////////////////////////////////////////

// �t�@�C�����̎擾
void getFiles(void){
  FILE_ENTRY *f;
  FILEINFO fi;
  char *name;

  pceFileFindOpen(&fi);

  while(pceFileFindNext(&fi) == 1){
    name = fi.filename;

    // startup.pex�͓o�^���Ȃ�
    if(strcmp(name, "startup.pex") == 0){
      continue;
    }

    f = newEntry();
    strcpy(f->name, name);
    f->size = fi.length;
    f->sectors = (fi.length + SECTOR_SIZE - 1) / SECTOR_SIZE;

    // *.pex�Ȃ���s�t�@�C��
    if(strcmp(name + strlen(name) - 4, ".pex") == 0){
      getCaption(f->caption, name);
      f->type = PEX;
      addEntry(uncategorizedProgram, f);
    }
    else{
      f->type = DATA;
      addEntry(uncategorizedData, f);
    }
  }
  pceFileFindClose(&fi);
}

////////////////////////////////////////////////////////////////////////////////

#define ICON_SIZE 32	// �A�C�R���̃s�N�Z����

// �f�t�H���g�A�C�R��
static char defaultIcon[]= {
   68,  68,  68,  68,  68,  68,  68,  68,  17,  17,  17,  17,  17,  17,  17,  17,
   68,  68,  68,  68,  68,  68,  68,  68,  17,  17,  17,  17,  17,  17,  17,  17,
   68,  68,  68,  68,  68,  68,  68,  68,  17,   0,   0,   0,  17,  17,  17,  17,
   70,  21,  85,  85,   4,  68,  68,  68,  18,  21,  85,  85,  64,   0,   1, 145,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70,  21,  85,  85,  85,  85,  86, 196,  18,  21,  85,  85,  85,  85,  86, 209,
   70, 170, 170, 170, 170, 170, 170, 196,  17,  17,  17,  17,  17,  17,  17,  17,
   68,  68,  68,  68,  68,  68,  68,  68,  17,  17,  17,  17,  17,  17,  17,  17,
   68,  68,  68,  68,  68,  68,  68,  68,  17,  17,  17,  17,  17,  17,  17,  17,
   68,  68,  68,  68,  68,  68,  68,  68,  17,  17,  17,  17,  17,  17,  17,  17
};

// �A�C�R���̕\��
void printIcon(int x, int y, const char *fileName){
  FILEACC facc;
  pffsFileHEADER *fileHeader;
  char fileBuffer[SECTOR_SIZE];
  int s, i, j;
  char *icon;
  unsigned char *p;

  pceFileOpen(&facc, fileName, FOMD_RD);
  s = pceFileReadSct(&facc, fileBuffer, 0, SECTOR_SIZE);
  pceFileClose(&facc);

  fileHeader = (pffsFileHEADER *)fileBuffer;

  // �A�C�R�����Ȃ���΃f�t�H���g�A�C�R�����g�p
  if((s < sizeof(pffsFileHEADER)) || (fileHeader->ofs_icon == 0)){
    icon = defaultIcon;
  }
  else{
    icon = fileBuffer + fileHeader->ofs_icon;
  }

  //1�o�C�g4�s�N�Z���ȈՕ`��
  for(j = 0; j < ICON_SIZE; j++){
    for(i = 0; i < ICON_SIZE / 4; i++){
      p = vbuff + (x + 4 * i) + DISP_X * (y + j);

      *(p + 0) = (*icon >> 6) & 0x03;
      *(p + 1) = (*icon >> 4) & 0x03;
      *(p + 2) = (*icon >> 2) & 0x03;
      *(p + 3) = (*icon >> 0) & 0x03;

      icon++;
    }
  }
}
