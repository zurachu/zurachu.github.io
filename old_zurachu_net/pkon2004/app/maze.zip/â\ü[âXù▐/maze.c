/*�{���ɍQ�Ăč�����̂Œ������ł��B���Ȃ��ق��������ł��B*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <piece.h>

#define MAX_X 60
#define MAX_Y 60
#define BLOCK 64
#define TRAP 72
#define WARP 120

#define SCROLL_X 40
#define SCROLL_Y 32

struct _Course
{
	int start_x,start_y;
	char name[20];
};
//�Ƃ����128,88 ��ʒ[40�h�b�g�ŃX�N���[��
int x=0,y=0,ana=0,jump=0,x_be_p=0,x_be_m=0,fall=0,get_y;
int graph_x=0,graph_y=0,scroll_x=0,scroll_y=0,old_x,death=0,graph_trap;
int last_judge_y=0,fake_x=0,fake_y=0,zero_x,zero_y,kyo,ryo;//��
char MAP[MAX_X][MAX_Y];//0:���� 1:�u���b�N 2-5:�j�㉺�E�� 6:�ʂ��� 7:�U�j
struct _Course course[26];
int debug=0,pre_debug=0,first_bright,bright;
int kotomi=0,tomoyo=0,nagisa=0,len_text,warp_zone=0;
long time,time2;

FILEINFO pmz;//�}�b�v�T��
FILEACC pfa;//�t�@�C���|�C���^

char text[3800];//�e�L�X�g

char sanae[20];
unsigned char vbuff[128*88];
static unsigned char draw;

char pmz_name[49][15];
int pmz_numb=0,page=0,death_style=0,death_x,death_y,death_g_x,death_g_y,death_s_x,death_s_y;

char open_file[20],File_name[20],S_X[5],S_Y[5];
int final_unko=0,last_warp=0,onegai=0,last_y=0,goal=0,clear_check=0;

//�C���[�W
extern unsigned char MAZE_C[];//�G�̃f�[�^�̎Q��
DRAW_OBJECT obj;            //�`����
PIECE_BMP   pbmp;           //�摜���

int a2i(char*str)
{
	int cnt;
	int num=0;
	for(cnt=0;(str[cnt]>='0') && (str[cnt]<='9');cnt++) 
	{
		num=10*num+(str[cnt]-'0');
	}
	return num;
}
void delay(unsigned long t)
{
	unsigned long t2;
	t2=pceTimerGetCount();
	while(1)
		if(pceTimerGetCount()-t2>=t)
			break;
}

//���[�Ȃ�ł������A�����Ƃ���Ă��̂ɕ���������̂ł����͋Z�ł���B��[����[�����񂱂��񂱁B
void map_search(void)
{
	int unko=0;
	char ppp[3],aho[20];
	pceFileFindOpen(&pmz);
	while(pceFileFindNext(&pmz))
	{
		strcpy(aho,pmz.filename);
		for(unko=0;unko<strlen(pmz.filename) || unko<50;unko++)
		{
			if(aho[unko] == '.')
			{
				ppp[0]=aho[unko+1];
				ppp[1]=aho[unko+2];
				ppp[2]=aho[unko+3];
				if(strcmp(ppp,"pmz")==0)
				{
					strcpy(pmz_name[pmz_numb],pmz.filename);
					pmz_numb++;
				}
				unko+=666;
			}
		}
	}
	pceFileFindClose(&pmz);
}

void map_read(int map_numb)
{
	scroll_x=0,scroll_y=0;
	jump=0,x_be_p=0,x_be_m=0,fall=0;
	if(pceFileOpen(&pfa,course[map_numb].name,FOMD_RD))//�J���񂩂���
	{
		
		
		for(kyo=1;kyo<MAX_X;kyo+=4)
		{
			for(ryo=1;ryo<MAX_Y;ryo+=4)
			{
				if(ryo%3==0 && kyo+(ryo%2)+1<MAX_X)
					MAP[kyo+(ryo%3)+1][ryo]=1;
				MAP[kyo+(ryo%2)][ryo]=1;
			}
		}
		for(ryo=0;ryo<MAX_Y;ryo++)
			MAP[0][ryo]=1;
	}
	else
	{
		x=(course[map_numb].start_x-1)*8;
		y=(course[map_numb].start_y-1)*8;
		pre_debug=(course[map_numb].start_x-1)*8;
		graph_x=x,graph_y=y;
		if(graph_x>352)
			graph_x=352;
		
		//�t�@�C���̓ǂݍ���
		pceFileReadSct(&pfa,text,0,3800);
		len_text=strlen(text);
		
		for(kyo=0,kotomi=0;kyo<len_text;kyo++,kotomi++)
		{
			if(text[kyo]>='0' && text[kyo]<='9')//�n�`
			{
				MAP[kotomi%60][kotomi/60]=text[kyo]-'0';
			}
			else if(text[kyo]>='A' && text[kyo]<='Z')//���[�v
			{
				MAP[kotomi%60][kotomi/60]=(text[kyo]-'A')+10;
			}
			else if(text[kyo]=='*')//�S�[���c�I
			{
				MAP[kotomi%60][kotomi/60]=99;
			}
			else
			{
				MAP[kotomi%60][kotomi/60]=1;
			}
			if(kotomi>=60 && kotomi%60==0)
			{	
				kyo+=2;
			}
		}
	}
	//�t�@�C�������
	pceFileClose(&pfa);
	
}

void next_map(int map_numb)
{
	for(kyo=first_bright;kyo<=63;kyo++)
	{
		pceLCDSetBright(kyo);
		delay(20);
	}
	map_read(map_numb);
	pceLCDSetBright(first_bright);
}

int Border_of_life(int x1,int y1,int x2,int y2,int style)//0:�ǂ̂� 1:�j�̂� 2�ȍ~:�S��
{
	int ex1=x1/8,ey1=y1/8,ex2=x2/8,ey2=y2/8,loop,ring;
	
	if(ex1>ex2)
	{
		loop=ex1;
		ex1=ex2;
		ex2=loop;
	}
	if(ey1>ey2)
	{
		loop=ey1;
		ey1=ey2;
		ey2=loop;
	}
	if(style==0)
	{
		for(loop=ex1;loop<=ex2;loop++)
		{
			for(ring=ey1;ring<=ey2;ring++)
			{
				if(MAP[loop][ring]==1)
					return 1;
			}
		}
	}
	if(style==1)
	{
		for(loop=ex1;loop<=ex2;loop++)
		{
			for(ring=ey1;ring<=ey2;ring++)
			{
				if(MAP[loop][ring]>=2 && MAP[loop][ring]<=5)
					return 1;
			}
		}
	}
	if(style==2)
	{
		for(loop=ex1;loop<=ex2;loop++)
		{
			for(ring=ey1;ring<=ey2;ring++)
			{
				if(MAP[loop][ring]==1)
					return 1;
				if(MAP[loop][ring]>=2 && MAP[loop][ring]<=5)
					return 2;
				if((MAP[loop][ring]>=10 && MAP[loop][ring]<=35) || MAP[loop][ring]==99)
					return MAP[loop][ring];
			}
		}
	}
	return 0;
}

void pceAppInit(void)
{
	unsigned char *vram;
	PBMP_FILEHEADER pbhead;
	pceLCDDispStop();
	pceLCDSetBuffer( vbuff );
	pceAppSetProcPeriod(70);
	memset( vbuff, 0, 128*88 );
	pceFontSetPos(1,1);
	pcePadSetTrigMode(PP_MODE_SINGLE);
	memcpy(&pbhead,MAZE_C,sizeof(PBMP_FILEHEADER));
	pbmp.header=pbhead;
	pbmp.buf=MAZE_C+sizeof(PBMP_FILEHEADER);
	first_bright=pceLCDSetBright(45);
	pceLCDSetBright(first_bright);
	
	for(kyo=0;kyo<MAX_X;kyo++)
		for(ryo=0;ryo<MAX_Y;ryo++)
			MAP[kyo][ryo]=0;
	
	map_search();
	
	pceLCDDispStart();
	ryo=0;
	if(pmz_numb==0)
	{
		pceFontSetPos(0,0);
		pceFontPrintf("�t�@�C���������̂ŏI�����܂�");
		pceLCDTrans();
		delay(1200);
		death=1;
	}
	else if(pmz_numb!=1)
	{
		y=0;
		while(y<7)
		{
			memset(vbuff,0,128*88);
			pceFontSetPos(0,0);
			pceFontPrintf("�R�[�X��I��ł�������",page+1,((pmz_numb-1)/7)+1);
			pceFontSetPos(0,78);
			pceFontPrintf("%d/%d",page+1,((pmz_numb-1)/7)+1);
			ryo=0;
			for(kyo=0;kyo+(page*7)<pmz_numb && kyo<7;kyo++)
			{
				ryo++;
				pceFontSetPos(20,(kyo*10)+10);
				pceFontPrintf("%s",pmz_name[kyo+(page*7)]);
			}
			pceFontSetPos(5,10+y*10);
			pceFontPrintf("��");
			
			pceLCDTrans();
			final_unko=0;
			while(final_unko==0)
			{
				pcePadGetProc();
				if((pcePadGet()&TRG_UP)!=0)
				{
					if(y!=0)
						y--;
					final_unko=1;
				}
				else if((pcePadGet()&TRG_DN)!=0)
				{
					if(y<6 && ((page)*7)+y+1 < pmz_numb)
					{
						y++;
					}
					final_unko=1;
				}
				else if((pcePadGet()&TRG_LF)!=0)
				{	
					if(page!=0)
						page--,y=0;
					final_unko=1;
				}
				else if((pcePadGet()&TRG_RI)!=0)
				{
					if(((page+1)*7)<pmz_numb)
						page++,y=0;
					final_unko=1;
				}
				else if((pcePadGet()&TRG_B)!=0 || (pcePadGet()&TRG_C)!=0 || (pcePadGet()&TRG_D)!=0 || (pcePadGet()&TRG_A)!=0)
				{
					strcpy(open_file,pmz_name[y+page*7]);
					y=100;
					final_unko=1;
				}
				pceLCDTrans();
			}
		}
	}
	else
	{
		strcpy(open_file,pmz_name[0]);
	}
	
	
	if(pceFileOpen(&pfa,open_file,FOMD_RD))//���s
	{
		pceFontSetPos(0,0);
		pceFontPrintf("�R�[�X���J���܂��� �I�����܂�%d",y);
		pceLCDTrans();
		delay(1200);
		death=1;
	}
	else
	{
		pceFileReadSct(&pfa,text,0,500);
		for(kyo=0;kyo<strlen(text);kyo++)
		{
			if(kotomi==0 && text[kyo]>='A' && text[kyo]<='Z')
			{
				tomoyo=text[kyo]-'A';
				kotomi=1;
			}
			else if(kotomi==1 && text[kyo]=='"')
			{
				kotomi=2;
				nagisa=0;
			}
			else if(kotomi==2 && text[kyo]=='"')
			{
				strncpy(course[tomoyo].name,File_name,nagisa);
				kotomi=3;
				nagisa=0;
			}
			else if(kotomi==2)
			{
				File_name[nagisa]=text[kyo];
				nagisa++;
			}
			else if(kotomi==3 && text[kyo]=='(')
			{
				kotomi=4;
				nagisa=0;
			}
			else if(kotomi==4 && text[kyo]==',')
			{
				course[tomoyo].start_x=a2i(S_X);
				kotomi=5;
				nagisa=0;
			}
			else if(kotomi==4)
			{
				S_X[nagisa]=text[kyo];
				nagisa++;
			}
			else if(kotomi==5 && text[kyo]==')')
			{
				course[tomoyo].start_y=a2i(S_Y);
				kotomi=0;
				nagisa=0;
			}
			else if(kotomi==5)
			{
				S_Y[nagisa]=text[kyo];
				nagisa++;
			}
		}
	}
	pceFileClose(&pfa);
	time2=pceTimerGetCount();
	map_search();
	pre_debug=(course[0].start_x-1)*8;
	
	map_read(0);
	
	
}


void pceAppProc(int cnt)
{
	memset(vbuff,0,128*88);
	
	time=pceTimerGetCount();
	if(time-time2>200)
	{
		time2=pceTimerGetCount();
		warp_zone++;
		death_style++;
		if(warp_zone==4)
		{	
		warp_zone=0;
		}
		if(death_style>5)
		{	
			if(goal==0)
				death_style=0;
			
			if(death==3)
			{
				death=4;
			}
		}
	}
	
	
	if((pcePadGet()&PAD_C)!=0)
	{
		pceLCDSetBright(first_bright);
		pceAppReqExit(0);
	}
	if(jump==0 && fall==0)
		last_judge_y=0;
	
	if(jump==0 || jump==5)
	{
		if(Border_of_life(x,y,x+6,y+7,0)!=1)
			fall=1;
	}
	if(jump>0 && jump<5)
	{
		if(Border_of_life(x,y,x+6,y,0)==1)
			fall=1;
	}
	
	if(fall==0 && goal==0)
	{
		if( ((pcePadGet()&PAD_UP)!=0 || (pcePadGet()&PAD_A)!=0)  && jump==0)
			jump++,get_y=0;
		if(jump==1)
		{
			if(Border_of_life(x,y-1,x+6,y-1,0)==1)
			{
				fall=0,jump=0;
			}
			else
			{
				if(get_y<24)
					y-=4,get_y+=4;
				else
					jump++;
			}
		}
		else if(jump==2)
		{
			if(Border_of_life(x,y-1,x+6,y-1,0)==1)
				fall=0,jump=0;
			else
			{
				if(get_y<26)
				{	
					y-=2,get_y+=2;
				}
				else
					jump++,get_y=0;
			}
		}
		else if(jump==3 || jump==4)
		{
			if(Border_of_life(x,y+8,x+6,y+8,0)==1)
			{	
				if(Border_of_life(x,y+7,x+6,y+7,0)==1)
					fall=0,jump=0;
				else
					y++,jump++;
			}
			else
				y+=2,jump++;
			
		}
	}
	else if((fall==1 || jump==5) && goal==0)
	{
		if(Border_of_life(x,y+10,x+6,y+10,0)==1)
		{	
			if(Border_of_life(x,y+8,x+6,y+8,0)!=1)
			{
				y+=2;
			}
			else if(Border_of_life(x,y+7,x+6,y+7,0)!=1)
			{
				y++;
			}
			else
				fall=0,jump=0;
		}
		else
		{	
			if(get_y==0)
			{
				y+=2,get_y=1;
			}
			else
				y+=4;
		}
		
	}
	
	/*��*/
	if((pcePadGet()&PAD_LF)!=0)
	{
		old_x=x;
		if(ana==7)
			ana=0;
		else
			ana++;
		if(x_be_m<3)
		{	
			x_be_m++;
			if(x_be_p>1)
				x_be_p=0;
			else
			{	
				if((Border_of_life(x,y,x-1,y+6,0)==1))
					x_be_m=0;
				else	
					x--;
			}
		}
		else
		{	
			if(x_be_p<3 && x_be_p>0)
			{	
				if((Border_of_life(x,y,x-1,y+6,0)!=1))
					x--;
			}	
			else if(x_be_p>=3)
				;
			else
			{
				if((Border_of_life(x,y,x-2,y+6,0)==1))
				{
					if(Border_of_life(x,y,x-1,y+6,0)!=1)
						x--;
				}
				else
					x-=2;
			}
		}
		if(x<0)
			x=0;
		
	}
	else if(x_be_m>0)
		x_be_m--;
	if(x_be_m>3)
		x_be_m=3;
	/*�E*/
	if((pcePadGet()&PAD_RI)!=0)
	{
		if(ana==0)
			ana=7;
		else
			ana--;
		if(x_be_p!=2)
			x_be_p++;
		if(x_be_p<3)
		{	
			x_be_p++;
			if(x_be_m>1)
				x_be_m=0;
			else
			{	
				if((Border_of_life(x,y,x+7,y+6,0)==1))
					x_be_p=0;
				else	
					x++;
			}	
		}
		else
		{	
			if(x_be_m<3 && x_be_m>0)
			{	
				if((Border_of_life(x,y,x+7,y+6,0)!=1))
					x++;
			}		
			else if(x_be_m>=3)
				;
			else
			{
				if((Border_of_life(x,y,x+8,y+6,0)==1))
				{
					if(Border_of_life(x,y,x+7,y+6,0)!=1)
						x++;
				}
				else
					x+=2;
			}
		}
		if(x>472)
			x=472;
	}
	else if(x_be_p>0)
		x_be_p--;
	if(x_be_p>3)
		x_be_p=3;
	
	
	/*X���W�X�N���[��*/
	fake_x=x-graph_x;
	if(fake_x>128-SCROLL_X)
	{
		if(graph_x>=((MAX_X)*8)-128)
		{
			graph_x=((MAX_X)*8)-128;
			scroll_x=0;
			fake_x=x-graph_x;
		}
		else
		{
			graph_x+=fake_x-(128-SCROLL_X);
			scroll_x+=fake_x-(128-SCROLL_X);
			fake_x=(128-SCROLL_X);
		}
	}
	else if(fake_x<SCROLL_X)
	{
		if(x<SCROLL_X)
		{
			graph_x=0;
			scroll_x=0;
			fake_x=x;
		}
		else
		{
			graph_x-=SCROLL_X-fake_x;
			scroll_x-=SCROLL_X-fake_x;
			fake_x=SCROLL_X;
		}
	}
	if(scroll_x>=8)
		scroll_x-=8;
	else if(scroll_x<0)
		scroll_x+=8;
	
	
	/*Y���W�X�N���[��*/
	fake_y=y-graph_y;
	if(fake_y>88-SCROLL_Y)
	{
		graph_y+=fake_y-(88-SCROLL_Y);
		scroll_y+=fake_y-(88-SCROLL_Y);
		fake_y=(88-SCROLL_Y);
	}
	else if(fake_y<SCROLL_Y)
	{
		if(y<SCROLL_Y)
		{
			graph_y=0;
			scroll_y=0;
			fake_y=y;
		}
		else
		{
			graph_y-=SCROLL_Y-fake_y;
			scroll_y-=SCROLL_Y-fake_y;
			fake_y=SCROLL_Y;
		}
	}
	
	if(scroll_y>=8)
		scroll_y-=8;
	else if(scroll_y<0)
		scroll_y+=8;
	
	if(death!=0)
	{
		fake_x=death_x;
		fake_y=death_y;
		graph_x=death_g_x;
		graph_y=death_g_y;
		scroll_x=death_s_x;
		scroll_y=death_s_y;
	}
	
	//�j�A���[�v�A�S�[���̐ڐG����
	
	if(Border_of_life(x,y,x+6,y+6,1)==1 && death==0 && goal==0)
		debug=jump,death=2;
	
	kyo=Border_of_life(x,y,x+6,y+6,2);
	if(kyo>=10 && kyo<=35 && goal==0)
	{	
		last_warp=kyo-10;
		next_map(kyo-10);
	}
	if(kyo==99)//goal
	{
		goal=1;
		death_style=0;
	}
	
	if(goal==1)
	{
		y-=2;
		if((pcePadGet()&PAD_UP)!=0 || (pcePadGet()&PAD_DN)!=0 || (pcePadGet()&PAD_LF)!=0 || (pcePadGet()&PAD_RI)!=0 || (pcePadGet()&PAD_A)!=0 || (pcePadGet()&PAD_B)!=0 || (pcePadGet()&PAD_C)!=0 || (pcePadGet()&PAD_D)!=0)
		{
			if(death_style>=3)
			{
			pceLCDSetBright(first_bright);
			pceAppReqExit(0);
			}
		}
	}
	
	if(death==1)
	{
		pceLCDSetBright(first_bright);
		pceAppReqExit(0);
	}	
	
	if(death==2)
	{
		death_x=fake_x-7;
		death_y=fake_y-5;
		death_g_x=graph_x;
		death_g_y=graph_y;
		death_s_x=scroll_x;
		death_s_y=scroll_y;
	
		death_style=0;
		death=3;
	}
	
	if(death==4)
	{
		onegai=0;
		last_y=0;
		while(onegai!=666)
		{
			memset(vbuff,0,128*88);
			pceFontSetPos(10,30);
			pceFontPrintf("�r������n�߂�");
			pceFontSetPos(10,40);
			pceFontPrintf("�ŏ�����n�߂�");
			pceFontSetPos(10,50);
			pceFontPrintf("�I������");
			pceFontSetPos(0,30+(last_y*10));
			pceFontPrintf("��");
			pceLCDTrans();
			
			final_unko=0;
			while(final_unko==0)
			{
				pcePadGetProc();
				if((pcePadGet()&TRG_UP)!=0)
				{
					if(last_y!=0)
						last_y--;
					final_unko=1;
				}
				else if((pcePadGet()&TRG_DN)!=0)
				{
					if(last_y!=2)
					{
						last_y++;
					}
					final_unko=1;
				}
				else if((pcePadGet()&TRG_B)!=0 || (pcePadGet()&TRG_C)!=0 || (pcePadGet()&TRG_D)!=0 || (pcePadGet()&TRG_A)!=0)
				{
					death=0;
					onegai=666;
					if(last_y==0)//continue
					{
						map_read(last_warp);
					}
					else if(last_y==1)//restart
					{
						map_read(0);
					}
					else if(last_y==2)//end
					{
						pceLCDSetBright(first_bright);
						pceAppReqExit(0);
					}
					final_unko=1;
				}
			}
			
		}
	}
	
	if(death==0)
	{
		pceLCDSetObject(&obj,&pbmp,fake_x,fake_y,ana*7,0,7,7,DRW_NOMAL);//�C���[�W�`��ݒ�
		pceLCDDrawObject(obj);
	}
	if(death==3)
	{
		pceLCDSetObject(&obj,&pbmp,death_x,death_y,death_style*16,9,15,15,DRW_NOMAL);//�C���[�W�`��ݒ�
		pceLCDDrawObject(obj);
	}
	if(graph_x!=0)
		zero_x=graph_x/8;
	else
		zero_x=0;
	if(graph_y!=0)
		zero_y=graph_y/8;
	else
		zero_y=0;
	
	for(kyo=1;kyo<15;kyo++)
	{	
		for(ryo=0;ryo<11;ryo++)
		{
			if(MAP[kyo+(zero_x)][ryo+(zero_y)]==1 || MAP[kyo+(zero_x)][ryo+(zero_y)]==6)
			{
				pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
			}
			else if((MAP[kyo+(zero_x)][ryo+(zero_y)]>=2 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=5) || MAP[kyo+(zero_x)][ryo+(zero_y)]==7)
			{
				graph_trap=MAP[kyo+(zero_x)][ryo+(zero_y)]-2;
				pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,TRAP+(8*graph_trap),0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
			}
			else if(MAP[kyo+(zero_x)][ryo+(zero_y)]>=10 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=35)//���[�v
			{	
				pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,WARP+warp_zone*8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
			}
			else if(MAP[kyo+(zero_x)][ryo+(zero_y)]==99)//�S�[��
			{
				pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK-8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
			}
		
		}
	}
	
	kyo=15;
	
	for(ryo=0;ryo<11;ryo++)
	{
		if(MAP[kyo+(zero_x)][ryo+(zero_y)]==1 || MAP[kyo+(zero_x)][ryo+(zero_y)]==6)
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if((MAP[kyo+(zero_x)][ryo+(zero_y)]>=2 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=5) || MAP[kyo+(zero_x)][ryo+(zero_y)]==7)
		{
			graph_trap=MAP[kyo+(zero_x)][ryo+(zero_y)]-2;
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,TRAP+(graph_trap*8),0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)]>=10 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=35)//���[�v
		{	
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,WARP+warp_zone*8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)]==99)//�S�[��
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK-8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		
		
		if(MAP[kyo+(zero_x)+1][ryo+(zero_y)]==1 || MAP[kyo+(zero_x)+1][ryo+(zero_y)]==6)
		{	
			pceLCDSetObject(&obj,&pbmp,((kyo+1)*8)-scroll_x,(ryo*8)-scroll_y,BLOCK,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if((MAP[kyo+(zero_x)+1][ryo+(zero_y)]>=2 && MAP[kyo+(zero_x)+1][ryo+(zero_y)]<=5) || MAP[kyo+(zero_x)+1][ryo+(zero_y)]==7)
		{
			graph_trap=MAP[kyo+(zero_x)+1][ryo+(zero_y)]-2;
			pceLCDSetObject(&obj,&pbmp,((kyo+1)*8)-scroll_x,(ryo*8)-scroll_y,TRAP+(graph_trap*8),0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)+1][ryo+(zero_y)]>=10 && MAP[kyo+(zero_x)+1][ryo+(zero_y)]<=35)//���[�v
		{	
			pceLCDSetObject(&obj,&pbmp,((kyo+1)*8)-scroll_x,(ryo*8)-scroll_y,WARP+warp_zone*8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)+1][ryo+(zero_y)]==99)//�S�[��
		{
			pceLCDSetObject(&obj,&pbmp,((kyo+1)*8)-scroll_x,(ryo*8)-scroll_y,BLOCK-8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		
		
		if(MAP[(zero_x)][ryo+(zero_y)]==1 || MAP[(zero_x)][ryo+(zero_y)]==6)
		{	
			pceLCDSetObject(&obj,&pbmp,0,(ryo*8)-scroll_y,BLOCK+scroll_x,0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if((MAP[(zero_x)][ryo+(zero_y)]>=2 && MAP[(zero_x)][ryo+(zero_y)]<=5) || MAP[(zero_x)][ryo+(zero_y)]==7)
		{	
			graph_trap=MAP[zero_x][ryo+zero_y]-2;
			pceLCDSetObject(&obj,&pbmp,0,(ryo*8)-scroll_y,TRAP+(graph_trap*8)+scroll_x,0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)]>=10 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=35)//���[�v
		{	
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,WARP+warp_zone*8,0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)]==99)//�S�[��
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK-8,0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
	}
	ryo=10;
	for(kyo=0;kyo<17;kyo++)
	{
		if(MAP[kyo+(zero_x)][ryo+(zero_y)]==1 || MAP[kyo+(zero_x)][ryo+(zero_y)]==6)
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if((MAP[kyo+(zero_x)][ryo+(zero_y)]>=2 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=5) || MAP[kyo+(zero_x)][ryo+(zero_y)]==7)
		{
			graph_trap=MAP[kyo+(zero_x)][ryo+(zero_y)]-2;
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,TRAP+(graph_trap*8),0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)]>=10 && MAP[kyo+(zero_x)][ryo+(zero_y)]<=35)//���[�v
		{	
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,WARP+warp_zone*8,0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)]==99)//�S�[��
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,(ryo*8)-scroll_y,BLOCK-8,0,8-scroll_x,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		
		
		if(MAP[kyo+(zero_x)][ryo+(zero_y)+1]==1 || MAP[kyo+(zero_x)][ryo+(zero_y)+1]==6)
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,((ryo+1)*8)-scroll_y,BLOCK,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if((MAP[kyo+(zero_x)][ryo+(zero_y)+1]>=2 && MAP[kyo+(zero_x)][ryo+(zero_y)+1]<=5) || MAP[kyo+(zero_x)][ryo+(zero_y)+1]==7)
		{
			graph_trap=MAP[kyo+(zero_x)][ryo+(zero_y+1)]-2;
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,((ryo+1)*8)-scroll_y,TRAP+(graph_trap*8),0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y)+1]>=10 && MAP[kyo+(zero_x)][ryo+(zero_y)+1]<=35)//���[�v
		{	
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,((ryo+1)*8)-scroll_y,WARP+warp_zone*8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
		else if(MAP[kyo+(zero_x)][ryo+(zero_y+1)]==99)//�S�[��
		{
			pceLCDSetObject(&obj,&pbmp,(kyo*8)-scroll_x,((ryo+1)*8)-scroll_y,BLOCK-8,0,8,8,DRW_NOMAL),pceLCDDrawObject(obj);
		}
	
	
	}
	if(goal==1 && clear_check==0)
	{
		pceLCDSetObject(&obj,&pbmp,44,39,96,9,40,10,DRW_NOMAL),pceLCDDrawObject(obj);
	}
	clear_check^=1;
	/*
	pceFontSetPos(0,0);
	pceFontPrintf("%3d %3d %d %d %d",x,y,(course[0].start_x-1)*8,(course[0].start_y-1)*8,pre_debug);
	*/
	pceLCDTrans();
}


void pceAppExit( void )
{
}

